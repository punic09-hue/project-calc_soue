import csv, re, math, sys
BASE="https://luis-lpa.ru/catalog/"
rows={}
for ln in open("raw.txt",encoding="utf-8"):
    ln=ln.rstrip("\n")
    if not ln: continue
    m,t,u,taps,spl,mx,ang,fr,dims,mass,ip=ln.split("|")
    rows[m]=dict(m=m,t=t,u=u,taps=taps,spl=spl,mx=mx,ang=ang,fr=fr,dims=dims,mass=mass,ip=ip)
# цветовые и прочие исполнения: (модель, база, url)
VAR=[("LPA-6W черный","LPA-6W","sirens-wall/lpa-6w-chernyy.html"),("LPA-6W небесно-синий","LPA-6W","sirens-wall/lpa-6w-nebesno-siniy.html"),
("LPA-6W серый","LPA-6W","sirens-wall/lpa-6w-seryy.html"),("LPA-10W EVA серый","LPA-10W EVA","sirens-wall/lpa-10w-eva-seryy.html"),
("LPA-6V черный","LPA-6V","sirens-wall/lpa-6v-chernyy.html"),("LPA-5W черный","LPA-5W","sirens-wall/lpa-5w-chernyy.html"),
("LPA-5N черный","LPA-5N","sirens-wall/lpa-5n-chyernyy.html"),("LPA-20MB","LPA-20MW","sirens-wall/lpa-20mb.html"),("LPA-40MB","LPA-40MW","sirens-wall/lpa-40mb.html"),
("LPA-10W3 черный","LPA-10W3","sirens-wall/lpa-10w3-chernyy.html"),("LPA-10W3 серый","LPA-10W3","sirens-wall/lpa-10w3-seryy.html"),
("LPA-MUSIC-30 белый","LPA-MUSIC-30","sirens-wall/lpa-music-30%20%D0%B1%D0%B5%D0%BB%D1%8B%D0%B9.html"),
("LPA-6C 0.75 черный","LPA-6C","sirens-ceiling/lpa-6c-0-75-chernyy.html"),("LPA-6C 0.75 серый","LPA-6C","sirens-ceiling/lpa-6c-0-75-seryy.html"),
("LPA-06CL20 черный","LPA-06CL20","sirens-ceiling/lpa-06cl20-chernyy.html"),("LPA-MUSIC-60 белый","LPA-MUSIC-60","column-mounted/lpa-music-60%20%D0%B1%D0%B5%D0%BB%D1%8B%D0%B9.html"),
("LPA-20CA черная","LPA-20CA","sound-column/lpa-20caA.html"),("LPA-40CA черная","LPA-40CA","sound-column/lpa-40caA.html"),("LPA-80CA черная","LPA-80CA","sound-column/lpa-80caA.html")]
TYPE={"ceil":("Громкоговоритель потолочный","потолок"),"wall":("Громкоговоритель настенный","стена"),"pend":("Громкоговоритель подвесной","подвес"),
"horn":("Громкоговоритель рупорный","стена"),"exhorn":("Громкоговоритель рупорный взрывозащищённый","стена"),"column":("Звуковая колонна","стена"),"projector":("Звуковой прожектор","стена")}
def num(x):
    x=x.replace(",",".")
    return float(x)
out=[]
def build(name,b,url,note_extra=""):
    t=b["t"]; typ,mount=TYPE[t]
    taps=re.sub(r"\s*\(.*","",b["taps"]); tl=[num(v) for v in taps.split("/")]; pmax=max(tl)
    note=[]
    if "0.75" in b["taps"]: note.append("есть исполнение 0.75 с отводом 0,75 Вт")
    S=""; L1=""
    spl=b["spl"]
    if spl.startswith("!"):
        v=spl[1:]; first=re.split(r"[/]",v)[0]; lo=num(re.split(r"-",first)[0])
        L1=f"{lo:g}"; S=f"{lo-10*math.log10(pmax):.1f}"
        note.append(f"на сайте «SPL, Ватт/метр {v} дБ»: по величине это УЗД при полной мощности; S пересчитана как L−10·lg Pмакс, уточнить по паспорту")
    elif spl:
        mm=re.match(r"([\d.]+)(±([\d.]+))?",spl); s=num(mm.group(1)); 
        if mm.group(3): s-=num(mm.group(3)); note.append(f"на сайте {spl} дБ — по п. В.3.5 принято меньшее")
        S=f"{s:g}"
    ang=b["ang"]; shdn=""; edge=""
    m1=re.search(r"1\s*кГц\s*([\d]+)°",ang) or re.search(r"([\d]+)°",ang)
    if m1: shdn=m1.group(1); edge="6"
    if b["m"]=="LPA-6C EVA" or name=="LPA-6C EVA":
        note.append("по круговой диаграмме ШДН на 1 кГц = 149° (на сайте и в паспорте 180°); принято 149° по п. В.4.2")
        shdn="149"
    if not shdn: note.append("угол направленности не указан — в калькуляторе 180°, уточнить по ТД")
    dims=[num(d) for d in re.findall(r"[\d.]+",b["dims"])] if b["dims"] else []
    if mount=="потолок": hb=0.02 if t=="ceil" else ""
    if t=="ceil": hb="0.02"; note.append("встраиваемый: низ корпуса ≈ уровень потолка")
    elif t=="pend": hb=f"{dims[-1]/1000:.2f}" if dims else ""
    else: hb=f"{dims[0]/1000:.2f}" if dims else ""; 
    if t!="ceil" and dims: note.append("высота корпуса — по первому габариту, уточнить ориентацию")
    if note_extra: note.insert(0,note_extra)
    out.append({"Производитель":"ЛУИС+ (LPA)","Модель":name,"Тип":typ,"Монтаж":mount,"Излучение":"однонаправленный","Питание":"проводной 100 В",
      "Отводы мощности, Вт":"/".join(f"{v:g}" for v in tl),"P макс, Вт":f"{pmax:g}","S, дБ (1 Вт, 1 м)":S,"L при P макс на 1 м, дБ":L1,
      "L речь на 1 м, дБА":"","L синус на 1 м, дБ":"","Макс. УЗД, дБ":b["mx"],"ШДН 1 кГц, °":shdn,"Ослабление на краю ШДН, дБ":edge,
      "Угол направленности (сайт)":ang,"Частоты, Гц":b["fr"],"Габариты, мм":b["dims"],"Высота корпуса, м":hb,"Масса, кг":b["mass"],"IP":b["ip"],
      "Источник":BASE+url,"Примечание":"; ".join(note)})
for m,b in rows.items(): build(m,b,b["u"])
for name,base,url in VAR: build(name,rows[base],url,f"исполнение {base}")
# сортировка: монтаж, модель
order={"потолок":0,"подвес":1,"стена":2}
out.sort(key=lambda r:(order[r["Монтаж"]],r["Тип"],r["Модель"]))
cols=list(out[0].keys())
with open(sys.argv[1],"w",encoding="utf-8-sig",newline="") as f:
    w=csv.DictWriter(f,fieldnames=cols,delimiter=";"); w.writeheader(); w.writerows(out)
print(len(out))
