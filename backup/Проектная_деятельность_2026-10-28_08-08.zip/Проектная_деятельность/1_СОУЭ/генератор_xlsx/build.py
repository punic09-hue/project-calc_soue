import os
import sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.formatting.rule import ColorScaleRule, CellIsRule, FormulaRule
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter as CL

OUT = sys.argv[1]
F = "Arial"
f = lambda **k: Font(name=F, size=k.pop("size", 10), **k)
BLUE = f(color="0000FF")
BOLD = f(bold=True)
H1 = f(bold=True, size=14)
H2 = f(bold=True, size=11, color="FFFFFF")
YEL = PatternFill("solid", fgColor="FFF2CC")
HEAD = PatternFill("solid", fgColor="1F4E78")
SUB = PatternFill("solid", fgColor="DDEBF7")
GREY = PatternFill("solid", fgColor="F2F2F2")
thin = Side(style="thin", color="BFBFBF")
BOX = Border(left=thin, right=thin, top=thin, bottom=thin)
WRAP = Alignment(wrap_text=True, vertical="top")
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
GREEN_F = PatternFill("solid", fgColor="C6EFCE"); RED_F = PatternFill("solid", fgColor="FFC7CE")

wb = Workbook()
names = {}
def name(n, ref):
    wb.defined_names[n] = DefinedName(n, attr_text=ref)

def section(ws, row, text, ncols=6):
    ws.cell(row, 1, text).font = H2
    for c in range(1, ncols + 1):
        ws.cell(row, c).fill = HEAD

# ---------------- Нормы ----------------
wn = wb.active; wn.title = "Нормы"
wn["A1"] = "Нормативные значения СП 3.13130.2026"; wn["A1"].font = H1
hdr = ["Категория помещения", "L_норм, дБА (мин.)", "Δ_ш, дБ (превышение над шумом)", "Верхний предел, дБА", "Пункт СП", "Примечание"]
for i, h in enumerate(hdr, 1):
    c = wn.cell(3, i, h); c.font = H2; c.fill = HEAD; c.alignment = CENTER; c.border = BOX
rows = [
    ("Прочее помещение", 65, 15, 110, "6.8.2, 6.8.4", "Уровень на высоте 1,5 м, при закрытых дверях"),
    ("Квартира", 55, 10, 110, "6.8.2, 6.8.4", "Уровень на высоте 1,5 м"),
    ("Спальное помещение", 75, 15, 95, "6.9.1", "На уровне головы спящего, диапазон 75–95 дБА"),
    ("Эксплуатируемая кровля", 65, 15, 110, "6.8.3, 6.8.4", "Δ_ш принят как для прочих помещений (допущение)"),
]
for r, row in enumerate(rows, 4):
    for c, v in enumerate(row, 1):
        cell = wn.cell(r, c, v); cell.font = f(); cell.border = BOX; cell.alignment = WRAP
name("CATS", "Нормы!$A$4:$A$7"); name("TBL_NORM", "Нормы!$A$4:$D$7")
extra = [
    ("Шум выше 85 дБА", 105, "6.8.2", "Требуется ≥ 105 дБА и обязательно световой и (или) тактильный способ"),
    ("Предел в зданиях Ф1.1", 95, "6.8.5", "Не более 95 дБА на высоте 1,5 м"),
    ("Разборчивость: макс. шум", 65, "6.11.3", "Эквивалентный уровень шума не выше 65 дБА"),
    ("Разборчивость: превышение речи над шумом", 10, "6.11.3", "LAeq,T речи на ≥ 10 дБ выше шума"),
    ("Разборчивость: шаг однонаправленных, м", 6, "6.11.3", "Расстояние между ОП; для одиночного ОП не применяется"),
    ("Разборчивость: шаг двунаправленных, м", 12, "6.11.3", "Расстояние между ОП; для одиночного ОП не применяется"),
    ("Мин. высота установки, м", 2.3, "6.18.1", "От пола до низа корпуса"),
    ("Охват разборчивостью, % площади", 0.9, "6.11.1", "Не менее 90 % площади на высоте 1,5 м"),
    ("Предв. ограничение: расстояние ОП — слушатель, м", 8, "В.7.4", "Для предварительных проектных решений"),
    ("Предв. ограничение: превышение над шумом, дБ", 15, "В.7.4", "В октавах 500/1000/2000 Гц; в калькуляторе — приближённо по дБА"),
    ("Предв. ограничение: расстояние между ОП, м", 16, "В.7.4", "Для одиночного ОП не применяется"),
    ("Макс. падение напряжения без данных ТД, %", 10, "В.3.4", "От номинального"),
]
wn["A9"] = "Прочие нормативные величины"; wn["A9"].font = BOLD
for i, h in enumerate(["Параметр", "Значение", "Пункт СП", "Примечание"], 1):
    c = wn.cell(10, i, h); c.font = H2; c.fill = HEAD; c.alignment = CENTER; c.border = BOX
for r, row in enumerate(extra, 11):
    for c, v in enumerate(row, 1):
        cell = wn.cell(r, c, v); cell.font = f(); cell.border = BOX; cell.alignment = WRAP
wn["B18"].number_format = "0%"
for n, r in [("N_NOISE85", 11), ("N_F11", 12), ("N_INT_NOISE", 13), ("N_INT_SNR", 14), ("N_STEP1", 15), ("N_STEP2", 16), ("N_HMIN", 17), ("N_COVER", 18),
             ("N_B74R", 19), ("N_B74SNR", 20), ("N_B74STEP", 21), ("N_DUMAX", 22)]:
    name(n, f"Нормы!$B${r}")
# Table B.1
wn["A24"] = "Таблица В.1 — справочный эквивалентный УЗД постоянного шума (прил. В, п. В.2.1)"; wn["A24"].font = BOLD
for i, h in enumerate(["Назначение помещения", "L_ш, дБА"], 1):
    c = wn.cell(25, i, h); c.font = H2; c.fill = HEAD; c.alignment = CENTER; c.border = BOX
b1 = [("Рабочие помещения адм.-упр. персонала производственных предприятий", 65),
      ("Диспетчерские, кабины наблюдения с телефонной связью, участки точной сборки, телефонные станции", 70),
      ("Лаборатории, помещения измерительных и аналитических работ, кабины наблюдения без телефонной связи", 75),
      ("Помещения и территории с постоянными рабочими местами производственных предприятий", 80),
      ("Кабинеты врачей", 50),
      ("Классы, аудитории, конференц-залы, читальные залы, зрительные залы клубов, залы суда, культовые залы", 60),
      ("Музыкальные классы", 70),
      ("Жилые комнаты квартир", 40),
      ("Жилые помещения общежитий, домов отдыха, пансионатов, палаты, иные спальные помещения (кроме квартир)", 50),
      ("Номера гостиниц", 50),
      ("Офисы, рабочие помещения и кабинеты административных и проектных организаций", 50),
      ("Залы кафе, ресторанов", 65),
      ("Фойе театров, кинотеатров, выставочных и концертных залов", 60),
      ("Зрительные залы театров и концертных залов", 60),
      ("Выставочные залы музеев, галерей, выставок", 70),
      ("Многоцелевые залы", 70),
      ("Кинотеатры", 70),
      ("Спортивные залы", 65),
      ("Торговые залы магазинов", 60),
      ("Пассажирские залы вокзалов и аэровокзалов", 60),
      ("Автостоянки", 70),
      ("Помещения для вентмашин", 80),
      ("Компрессорные и насосные", 80),
      ("Серверные и коммутационные в общественных зданиях", 65),
      ("Кухни ресторанов и кафе", 70),
      ("Стадионы", 80),
      ("Ванные, душевые, санузлы", 55),
      ("Машинные залы ЦОД", 95),
      ("Ф5: помещения и прилегающие территории (не менее, п. В.2.2)", 60)]
for k, (t, v) in enumerate(b1, 26):
    a = wn.cell(k, 1, t); a.font = f(); a.border = BOX; a.alignment = WRAP
    b = wn.cell(k, 2, v); b.font = f(); b.border = BOX; b.alignment = Alignment(horizontal="center")
b1end = 26 + len(b1) - 1
name("NAMES_B1", f"Нормы!$A$26:$A${b1end}"); name("TBL_B1", f"Нормы!$A$26:$B${b1end}")
wn.cell(b1end + 1, 1, "Коридоры — по уровню шума в помещениях, имеющих с ними прямое сообщение (поз. 21): введите L_ш вручную. Фактический уровень уточняется при вводе в эксплуатацию.").font = f(italic=True, color="595959")
wn.cell(b1end + 3, 1, "Источник: СП 3.13130.2026, утв. приказом МЧС России от 26.02.2026 № 133, действует с 01.06.2026; пп. 6.8, 6.9, 6.11, 6.18, приложение В.").font = f(italic=True)
for col, w in zip("ABCDEF", [38, 16, 22, 18, 14, 50]):
    wn.column_dimensions[col].width = w

# ---------------- Расчёт ----------------
ws = wb.create_sheet("Расчёт", 0)
ws["A1"] = "Расчёт УЗД одиночного речевого оповещателя по СП 3.13130.2026"; ws["A1"].font = H1
ws["A2"] = "Заполняйте только жёлтые ячейки (синий шрифт). Остальное считается автоматически. Значения ниже — пример из методики."
ws["A2"].font = f(italic=True, color="595959")

inputs = [
    # key, label, value, unit, note
    (None, "Помещение и нормы"),
    ("CAT", "Категория помещения", "Прочее помещение", "", "Выбор из списка, нормы — на листе «Нормы»"),
    ("IS_F11", "Здание класса Ф1.1", "Нет", "", "Да — верхний предел 95 дБА (п. 6.8.5)"),
    ("PURP", "Назначение помещения (табл. В.1)", "Офисы, рабочие помещения и кабинеты административных и проектных организаций", "", "Даёт справочный L_ш, если нет замеров"),
    ("LNM", "L_ш по замерам / заданию (если есть)", "", "дБА", "Пусто — берётся из табл. В.1 (п. В.2.1, 6.8.6)"),
    ("RA", "Длина помещения a (ось X)", 12, "м", ""),
    ("RB", "Ширина помещения b (ось Y)", 8, "м", ""),
    ("RH", "Высота помещения H", 3, "м", ""),
    ("TREV", "Время реверберации T60", 0.8, "с", "Только для справочного режима с отражённым полем"),
    ("HRT", "Высота расчётной точки h_рт", 1.5, "м", "1,5 м; для спален — уровень головы спящего"),
    (None, "Оповещатель"),
    ("TYP", "Тип установки", "Настенный", "", "Настенный — ось горизонтальна; Потолочный — ось вниз"),
    ("DIR", "Направленность", "Однонаправленный", "", "Двунаправленный — излучает по оси в обе стороны"),
    ("LSENS", "Чувствительность S (1 кГц, 1 Вт, 1 м)", 89, "дБ", "Из ТД (В.3.2); при диапазоне — наименьшее (В.3.5); на 1 кГц дБ = дБА (В.5)"),
    ("PW", "Мощность подключения P (отвод)", 3, "Вт", "Формула (В.1)"),
    ("LMAXP", "Макс. УЗД на 1 м по ТД", "", "дБ", "Необязательно; пусто — без ограничения"),
    ("DU", "Падение напряжения в линии ΔU", 0, "%", "Без данных ТД — не более 10 % (В.3.4)"),
    ("DIRM", "Учёт направленности (В.4.2)", "По углу раскрыва (−6 дБ)", "", "Диаграмма — по таблице ниже; угол раскрыва — 6 дБ во всей зоне; кривая 2-го порядка по 3 точкам"),
    ("PHI", "Угол раскрыва φ (ШДН, по уровню −6 дБ)", 90, "°", "Из ТД"),
    ("QQ", "Коэффициент направленности Q", 2, "", "Только для справочного режима; если нет в ТД — 2"),
    ("XOP", "Координата X оповещателя", 0, "м", "Начало координат — угол помещения"),
    ("YOP", "Координата Y оповещателя", 4, "м", ""),
    ("HOP", "Высота установки h_оп", 2.5, "м", "Не менее 2,3 м до низа корпуса (п. 6.18.1)"),
    ("AZ", "Азимут оси в плане (для настенного)", 0, "°", "0° — вдоль +X, 90° — вдоль +Y"),
    ("DOP", "Дополнительные потери", 0, "дБ", "Затенение мебелью, стеллажами и т. п."),
    ("CALC_MODE", "Режим расчёта", "Прямой звук", "", "Прямой звук — формула (В.2); с отражённым полем — справочно, вне прил. В (В.1.2)"),
]
r = 4
for c, h in enumerate(["Параметр", "Значение", "Ед.", "Пояснение"], 1):
    cell = ws.cell(r, c, h); cell.font = BOLD; cell.fill = SUB; cell.border = BOX
r += 1
for item in inputs:
    if item[0] is None:
        ws.cell(r, 1, item[1]).font = BOLD; ws.cell(r, 1).fill = GREY
        for c in range(2, 5): ws.cell(r, c).fill = GREY
        r += 1; continue
    key, label, val, unit, note = item
    ws.cell(r, 1, label).font = f(); ws.cell(r, 3, unit).font = f(); ws.cell(r, 4, note).font = f(color="595959")
    v = ws.cell(r, 2, val); v.font = BLUE; v.fill = YEL; v.border = BOX; v.alignment = Alignment(horizontal="center")
    names[key] = f"$B${r}"
    name(key, f"Расчёт!$B${r}")
    r += 1

def dv(formula, key):
    d = DataValidation(type="list", formula1=formula, allow_blank=False); ws.add_data_validation(d); d.add(names[key])
dv("=CATS", "CAT"); dv('"Да,Нет"', "IS_F11"); dv('"Настенный,Потолочный"', "TYP")
dv('"Однонаправленный,Двунаправленный"', "DIR"); dv('"Прямой звук,С отражённым полем"', "CALC_MODE")
dv("=NAMES_B1", "PURP"); dv('"По диаграмме (таблица),По углу раскрыва (−6 дБ),Кривая 2-го порядка"', "DIRM")
ws[names["PURP"].replace("$", "")].alignment = Alignment(wrap_text=True, horizontal="center")

# Diagram table
r += 1
ws.cell(r, 1, "Диаграмма направленности: ослабление ΔL(θ) относительно оси, дБ").font = BOLD
ws.cell(r, 1).fill = GREY
for c in range(2, 5): ws.cell(r, c).fill = GREY
r += 1
ws.cell(r, 1, "Перенесите из паспорта. Между узлами — линейная интерполяция. Значения ниже — типовые для φ = 90°.").font = f(italic=True, color="595959")
r += 1
ws.cell(r, 1, "Угол θ, °").font = BOLD; ws.cell(r, 2, "ΔL, дБ").font = BOLD
for c in (1, 2): ws.cell(r, c).fill = SUB; ws.cell(r, c).border = BOX
r += 1
diag = [0, 1, 3, 6, 9, 12, 15, 18, 20, 20, 20, 20, 20]
d0 = r
for i, v in enumerate(diag):
    a = ws.cell(r, 1, i * 15); a.font = f(); a.border = BOX; a.alignment = Alignment(horizontal="center")
    b = ws.cell(r, 2, v); b.font = BLUE; b.fill = YEL; b.border = BOX; b.alignment = Alignment(horizontal="center")
    r += 1
name("DIAG", f"Расчёт!$B${d0}:$B${d0+12}")

# Derived results in columns F-I
R0 = 4
for c, h in enumerate(["Расчётная величина", "Значение", "Ед.", "Формула / пункт СП"], 6):
    cell = ws.cell(R0, c, h); cell.font = BOLD; cell.fill = SUB; cell.border = BOX
calc = [
    ("L_NOISE", "Принятый L_ш", '=IF(ISNUMBER(LNM),LNM,VLOOKUP(PURP,TBL_B1,2,FALSE))', "дБА", "Замеры или табл. В.1"),
    ("DLU", "Поправка на падение напряжения ΔL_U", "=20*LOG10(1-DU/100)", "дБ", "20·lg(1 − ΔU), В.3.4"),
    ("LNORM", "Нормативный минимум L_норм", "=VLOOKUP(CAT,TBL_NORM,2,FALSE)", "дБА", "п. 6.8.2, 6.8.3, 6.9.1"),
    ("DN", "Превышение над шумом Δ_ш", "=VLOOKUP(CAT,TBL_NORM,3,FALSE)", "дБ", "п. 6.8.2, 6.9.1"),
    ("LTR", "Требуемый уровень L_тр", "=IF(L_NOISE>N_NOISE85,N_NOISE85+0*0+105-N_NOISE85,MAX(LNORM,L_NOISE+DN))", "дБА", "max(L_норм; L_ш + Δ_ш); при шуме > 85 — 105 дБА"),
    ("LUP", "Верхний предел", '=IF(IS_F11="Да",MIN(N_F11,VLOOKUP(CAT,TBL_NORM,4,FALSE)),VLOOKUP(CAT,TBL_NORM,4,FALSE))', "дБА", "п. 6.8.4, 6.8.5, 6.9.1"),
    ("L1M", "УЗД на оси на 1 м L_p1 (с ΔL_U)", '=IF(ISNUMBER(LMAXP),MIN(LSENS+10*LOG10(PW),LMAXP),LSENS+10*LOG10(PW))+DLU', "дБ", "(В.1): S + 10·lg P, не выше L_max; + ΔL_U"),
    ("DH", "Перепад высот Δh", "=HOP-HRT", "м", "h_оп − h_рт"),
    ("SS", "Площадь ограждений S", "=2*(RA*RB+RA*RH+RB*RH)", "м²", "2(ab + aH + bH)"),
    ("VV", "Объём V", "=RA*RB*RH", "м³", ""),
    ("ALF", "Средний коэф. звукопоглощения ᾱ", "=MIN(0.99,0.161*VV/(SS*TREV))", "", "Сэбин: 0,161·V / (S·T60)"),
    ("RR", "Постоянная помещения R", "=SS*ALF/(1-ALF)", "м²", "S·ᾱ / (1 − ᾱ)"),
    ("R_CRIT", "Критический радиус r_к", "=SQRT(QQ*RR/(16*PI()))", "м", "Дальше r_к преобладает отражённый звук"),
    ("RMAX", "Радиус охвата r_max (на границе зоны, прямой звук)", '=10^((L1M-DOP-IF(DIRM="По диаграмме (таблица)",INDEX(DIAG,1),IF(DIRM="Кривая 2-го порядка",0,6))-LTR)/20)', "м", "Из (В.2); для угла раскрыва — с ΔL = 6 дБ"),
    ("LCLOSE", "УЗД в ближайшей точке (r = max(1; Δh))", "=L1M-DOP-20*LOG10(MAX(1,DH))", "дБА", "Консервативно: на оси"),
]
rr = R0 + 1
for key, label, fml, unit, note in calc:
    ws.cell(rr, 6, label).font = f()
    c = ws.cell(rr, 7, fml); c.font = f(); c.border = BOX; c.number_format = "0.0"; c.alignment = Alignment(horizontal="center")
    ws.cell(rr, 8, unit).font = f(); ws.cell(rr, 9, note).font = f(color="595959")
    names[key] = f"$G${rr}"; name(key, f"Расчёт!$G${rr}")
    rr += 1
ws["G" + names["ALF"][3:]].number_format = "0.00"
# fix LTR formula cleanly
ws[names["LTR"].replace("$", "")] = "=IF(L_NOISE>N_NOISE85,105,MAX(LNORM,L_NOISE+DN))"

# Verdict block
rr += 1
ws.cell(rr, 6, "ИТОГ").font = H2
for c in range(6, 10): ws.cell(rr, c).fill = HEAD
rr += 1
VERD0 = rr
verd = [
    ("Слышимость во всех контрольных точках", '=IF(COUNTIF(PT_OK1,"Нет")=0,"Выполнено","Не выполнено")', "п. 6.8.2 / 6.9.1"),
    ("Верхний предел УЗД", '=IF(LCLOSE<=LUP,"Выполнено","Не выполнено")', "п. 6.8.4 / 6.8.5 / 6.9.1"),
    ("Разборчивость по п. 6.11.3 во всех точках", '=IF(COUNTIF(PT_OK3,"Нет")=0,"Выполнено","Не выполнено")', "п. 6.11.3 (шаг между ОП для одного ОП не применяется)"),
    ("Предв. ограничения В.7.4 во всех точках", '=IF(COUNTIF(PT_OK4,"Нет")=0,"Выполнено","Не выполнено")', "В.7.4: r ≤ 8 м, превышение ≥ 15 дБ; иначе прогноз по ГОСТ Р ИСО 9921"),
    ("Высота установки", '=IF(HOP>=N_HMIN,"Выполнено","Не выполнено")', "п. 6.18.1"),
    ("Слышимость по карте, % площади", "=COUNTIF(MAP_L,\">=\"&LTR)/COUNT(MAP_L)", "лист «Карта УЗД»"),
    ("Разборчивость по п. 6.11.3 по карте, % площади", "=COUNTIF(MAP_I,1)/COUNT(MAP_I)", "п. 6.11.1: не менее 90 %"),
    ("Ограничения В.7.4 по карте, % площади", "=COUNTIF(MAP_J,1)/COUNT(MAP_J)", "справочно"),
    ("Шум > 85 дБА: нужен световой / тактильный способ", '=IF(L_NOISE>N_NOISE85,"Да","Нет")', "п. 6.8.2"),
]
for label, fml, note in verd:
    ws.cell(rr, 6, label).font = f()
    c = ws.cell(rr, 7, fml); c.font = BOLD; c.border = BOX; c.alignment = Alignment(horizontal="center")
    ws.cell(rr, 9, note).font = f(color="595959")
    rr += 1
for k in (5, 6, 7): ws.cell(VERD0 + k, 7).number_format = "0%"
vr = f"G{VERD0}:G{VERD0+4}"
ws.conditional_formatting.add(vr, CellIsRule(operator="equal", formula=['"Выполнено"'], fill=GREEN_F))
ws.conditional_formatting.add(vr, CellIsRule(operator="equal", formula=['"Не выполнено"'], fill=RED_F))
ws.conditional_formatting.add(f"G{VERD0+6}", CellIsRule(operator="greaterThanOrEqual", formula=["N_COVER"], fill=GREEN_F))
ws.conditional_formatting.add(f"G{VERD0+6}", CellIsRule(operator="lessThan", formula=["N_COVER"], fill=RED_F))

# ---------------- Control points ----------------
P0 = max(r, rr) + 2
section(ws, P0, "Контрольные точки (координаты в плане можно менять; по умолчанию — углы и центр помещения)", 17)
ph = ["Точка", "X, м", "Y, м", "d в плане, м", "r, м", "cos θ", "θ, °", "ΔL(θ), дБ", "В зоне раскрыва", "L прямой, дБА",
      "L с отраж., дБА", "L расчётный, дБА", "Запас, дБ", "Слышимость", "6.11.3: шум ≤ 65, S/N ≥ 10", "В.7.4: r ≤ 8 м", "В.7.4: S/N ≥ 15"]
for i, h in enumerate(ph, 1):
    c = ws.cell(P0 + 1, i, h); c.font = BOLD; c.fill = SUB; c.border = BOX; c.alignment = CENTER
ws.row_dimensions[P0 + 1].height = 30
pts = [("Угол 1", "=0", "=0"), ("Угол 2", "=RA", "=0"), ("Угол 3", "=RA", "=RB"), ("Угол 4", "=0", "=RB"),
       ("Центр", "=RA/2", "=RB/2"), ("Точка 6", None, None), ("Точка 7", None, None), ("Точка 8", None, None)]
def cosexpr(dx, dy, rexpr):
    return (f'IF(TYP="Потолочный",DH/{rexpr},'
            f'IF(DIR="Двунаправленный",ABS({dx}*COS(RADIANS(AZ))+{dy}*SIN(RADIANS(AZ))),'
            f'{dx}*COS(RADIANS(AZ))+{dy}*SIN(RADIANS(AZ)))/{rexpr})')
def dlexpr(th):
    i = f"MIN(INT({th}/15),11)"
    tab = f"(INDEX(DIAG,{i}+1)+({th}-15*{i})/15*(INDEX(DIAG,{i}+2)-INDEX(DIAG,{i}+1)))"
    return (f'IF(DIRM="По диаграмме (таблица)",{tab},'
            f'IF(DIRM="Кривая 2-го порядка",MIN(30,6*({th}/(PHI/2))^2),'
            f'IF({th}<=PHI/2,6,MAX(6,{tab}))))')
first = P0 + 2
for k, (nm, x, y) in enumerate(pts):
    row = first + k
    ws.cell(row, 1, nm).font = f()
    for col, v in ((2, x), (3, y)):
        c = ws.cell(row, col, v); c.font = BLUE; c.fill = YEL
    R = str(row)
    def blank(expr): return f'=IF(OR(B{R}="",C{R}=""),"",{expr})'
    ws.cell(row, 4, blank(f"SQRT((B{R}-XOP)^2+(C{R}-YOP)^2)"))
    ws.cell(row, 5, blank(f"MAX(0.1,SQRT(D{R}^2+DH^2))"))
    ws.cell(row, 6, blank("MAX(-1,MIN(1," + cosexpr(f"(B{R}-XOP)", f"(C{R}-YOP)", f"E{R}") + "))"))
    ws.cell(row, 7, blank(f"DEGREES(ACOS(F{R}))"))
    ws.cell(row, 8, blank(dlexpr(f"G{R}")))
    ws.cell(row, 9, blank(f'IF(G{R}<=PHI/2,"Да","Нет")'))
    ws.cell(row, 10, blank(f"L1M-DOP-20*LOG10(E{R})-H{R}"))
    ws.cell(row, 11, blank(f"L1M-DOP+10*LOG10(10^(-H{R}/10)/E{R}^2+16*PI()/(QQ*RR))"))
    ws.cell(row, 12, blank(f'IF(CALC_MODE="Прямой звук",J{R},K{R})'))
    ws.cell(row, 13, blank(f"L{R}-LTR"))
    ws.cell(row, 14, blank(f'IF(AND(L{R}>=LTR,OR(CAT<>"Спальное помещение",L{R}<=LUP)),"Да","Нет")'))
    ws.cell(row, 15, blank(f'IF(AND(L_NOISE<=N_INT_NOISE,J{R}-L_NOISE>=N_INT_SNR),"Да","Нет")'))
    ws.cell(row, 16, blank(f'IF(E{R}<=N_B74R,"Да","Нет")'))
    ws.cell(row, 17, blank(f'IF(J{R}-L_NOISE>=N_B74SNR,"Да","Нет")'))
    for col in range(1, 18):
        c = ws.cell(row, col); c.border = BOX; c.alignment = Alignment(horizontal="center")
        if col not in (2, 3): c.font = f()
        if col in (4, 5, 7, 8, 10, 11, 12, 13): c.number_format = "0.0"
        if col == 6: c.number_format = "0.000"
last = first + len(pts) - 1
name("PT_OK1", f"Расчёт!$N${first}:$N${last}"); name("PT_OK3", f"Расчёт!$O${first}:$O${last}"); name("PT_OK4", f"Расчёт!$P${first}:$Q${last}")
rng = f"I{first}:Q{last}"
ws.conditional_formatting.add(rng, CellIsRule(operator="equal", formula=['"Да"'], fill=GREEN_F))
ws.conditional_formatting.add(rng, CellIsRule(operator="equal", formula=['"Нет"'], fill=RED_F))
ws.cell(last + 1, 1, "Слышимость: «L расчётный» (выбранный режим) против L_тр. Разборчивость — по прямому звуку (В.2). При угле раскрыва точки вне зоны (θ > φ/2) считаются не хуже диаграммы, но не лучше −6 дБ.").font = f(italic=True, color="595959")

for col, w in zip("ABCDEFGHIJKLMNOPQ", [44, 34, 8, 46, 12, 42, 14, 10, 40, 12, 12, 13, 10, 12, 16, 12, 14]):
    ws.column_dimensions[col].width = w
ws.freeze_panes = "A4"

# ---------------- Map ----------------
N = 20
wm = wb.create_sheet("Карта УЗД", 1)
wm["A1"] = "Карта УЗД на высоте h_рт (расчётный режим), дБА"; wm["A1"].font = H1
wm["A2"] = f"Сетка {N}×{N} по центрам ячеек. Зелёное — не ниже L_тр, красное — ниже. Строки — Y, столбцы — X."
wm["A2"].font = f(italic=True, color="595959")
wm["A3"] = "L_тр, дБА:"; wm["B3"] = "=LTR"; wm["A3"].font = BOLD; wm["B3"].font = BOLD; wm["B3"].number_format = "0.0"
helper = wb.create_sheet("Служебный")
helper["A1"] = "Служебные расчёты для карты (θ, ΔL, разборчивость). Не редактировать."; helper["A1"].font = BOLD
top, left = 5, 2
wm.cell(top - 1, 1, "Y \\ X, м").font = BOLD
for j in range(N):
    c = wm.cell(top - 1, left + j, f"=(COLUMN()-{left}+0.5)*RA/{N}"); c.font = BOLD; c.number_format = "0.0"; c.alignment = CENTER
    wm.column_dimensions[CL(left + j)].width = 6.5
for i in range(N):
    c = wm.cell(top + i, 1, f"=(ROW()-{top}+0.5)*RB/{N}"); c.font = BOLD; c.number_format = "0.0"; c.alignment = CENTER
wm.column_dimensions["A"].width = 12
# helper blocks: theta (rows 3..), DL, intelligibility
hT, hD, hI, hJ = 3, 3 + N + 2, 3 + 2 * (N + 2), 3 + 3 * (N + 2)
helper.cell(hT - 1, 1, "θ, °"); helper.cell(hD - 1, 1, "ΔL, дБ"); helper.cell(hI - 1, 1, "Разборчивость 6.11.3 (1/0)"); helper.cell(hJ - 1, 1, "Ограничения В.7.4 (1/0)")
for i in range(N):
    for j in range(N):
        X = f"'Карта УЗД'!{CL(left+j)}${top-1}"; Y = f"'Карта УЗД'!$A{top+i}"
        dx, dy = f"({X}-XOP)", f"({Y}-YOP)"
        d = f"SQRT({dx}^2+{dy}^2)"
        r_ = f"MAX(0.1,SQRT({dx}^2+{dy}^2+DH^2))"
        th = f"{CL(left+j)}{hT+i}"
        helper.cell(hT + i, left + j, "=DEGREES(ACOS(MAX(-1,MIN(1," + cosexpr(dx, dy, r_) + "))))")
        helper.cell(hD + i, left + j, "=" + dlexpr(th))
        dl = f"Служебный!{CL(left+j)}{hD+i}"
        ldir = f"(L1M-DOP-20*LOG10({r_})-{dl})"
        lrev = f"(L1M-DOP+10*LOG10(10^(-{dl}/10)/({r_})^2+16*PI()/(QQ*RR)))"
        wm.cell(top + i, left + j, f'=IF(CALC_MODE="Прямой звук",{ldir},{lrev})').number_format = "0"
        wm.cell(top + i, left + j).font = f(size=9); wm.cell(top + i, left + j).alignment = CENTER
        helper.cell(hI + i, left + j, f"=IF(AND(L_NOISE<=N_INT_NOISE,{ldir}-L_NOISE>=N_INT_SNR),1,0)")
        helper.cell(hJ + i, left + j, f"=IF(AND({r_}<=N_B74R,{ldir}-L_NOISE>=N_B74SNR),1,0)")
mr = f"{CL(left)}{top}:{CL(left+N-1)}{top+N-1}"
name("MAP_L", f"'Карта УЗД'!${CL(left)}${top}:${CL(left+N-1)}${top+N-1}")
name("MAP_I", f"Служебный!${CL(left)}${hI}:${CL(left+N-1)}${hI+N-1}")
name("MAP_J", f"Служебный!${CL(left)}${hJ}:${CL(left+N-1)}${hJ+N-1}")
wm.conditional_formatting.add(mr, CellIsRule(operator="greaterThanOrEqual", formula=["LTR"], fill=GREEN_F))
wm.conditional_formatting.add(mr, CellIsRule(operator="lessThan", formula=["LTR"], fill=RED_F))
wm.freeze_panes = wm.cell(top, left)
helper.sheet_state = "hidden"

# ---------------- Методика ----------------
wt = wb.create_sheet("Методика")
lines = [
    ("Методика расчёта (сверена с приложением В к СП 3.13130.2026)", H1),
    ("Модель: оповещатель — точечный источник, прямой звук по формулам (В.1) и (В.2). Режим с отражённым полем — справочный, в прил. В его нет (допускается по В.1.2).", None),
    ("1. (В.1): L_p1 = S + 10·lg P; S — опорный УЗД на 1 кГц при 1 Вт на 1 м; при диапазоне в ТД — наименьшее значение (В.3.5); не выше макс. УЗД по ТД", None),
    ("2. Падение напряжения (В.3.4): без данных ТД не более 10 %; поправка ΔL_U = 20·lg(1 − ΔU) — наша формула (мощность ∝ U²)", None),
    ("3. Расстояние (В.6.1): Δh = h_оп − h_рт; r₂ = √(d² + Δh²), вдоль луча из ОП", None),
    ("4. Направленность (В.4.2): θ — угол от рабочей оси (настенный — по азимуту, потолочный — вниз). ΔL(θ): по полярной диаграмме; или по углу раскрыва — 6 дБ во всей зоне θ ≤ φ/2; или кривая 2-го порядка по 3 точкам: 6·(θ/(φ/2))²", None),
    ("5. (В.2): L_p2 = L_p1 + 20·lg(r₁/r₂) − ΔL(θ) + ΔL_U − доп. потери, r₁ = 1 м. Условия: +5…+35 °C, влажность ≤ 80 %, без препятствий и отражений (В.6.2)", None),
    ("6. Требуемый уровень: L_тр = max(L_норм; L_ш + Δ_ш) (п. 6.8.2, 6.8.3, 6.9.1); при L_ш > 85 дБА — 105 дБА и световой/тактильный способ. L_ш — замеры или табл. В.1", None),
    ("7. Верхний предел в ближайшей точке r = max(1 м; Δh) на оси: ≤ 110 дБА (6.8.4), Ф1.1 — ≤ 95 дБА (6.8.5), спальни — ≤ 95 дБА (6.9.1)", None),
    ("8. Разборчивость, п. 6.11.3: L_ш ≤ 65 дБА; LAeq,T речи − L_ш ≥ 10 дБ по всей площади; требование к шагу 6/12 м — между ОП, для одного ОП не применяется. Охват ≥ 90 % площади (6.11.1)", None),
    ("9. Предварительные ограничения В.7.4: до слушателя ≤ 8 м; превышение над шумом в октавах 500/1000/2000 Гц ≥ 15 дБ (в калькуляторе — приближённо по дБА); между ОП ≤ 16 м. При невыполнении — прогноз по ГОСТ Р ИСО 9921 или программам изготовителя (В.7.1, В.7.2)", None),
    ("10. Справочно: R = S_огр·ᾱ/(1 − ᾱ), ᾱ = 0,161·V/(S_огр·T60), L = L_p1 + 10·lg(10^(−ΔL/10)/r² + 16π/(Q·R)), критический радиус r_к = √(Q·R/16π)", None),
    ("", None),
    ("Допущения и ограничения", BOLD),
    ("• Расчёт на 1 кГц: неравномерность АЧХ (В.3.3) и частотная зависимость диаграмм (В.4.4) не учитываются. Данные ТД без коррекции по А приводить по табл. В.2.", None),
    ("• Диаграммы в горизонтальной и вертикальной плоскостях могут различаться (В.4.3): вводите худшую.", None),
    ("• Ослабление через двери — только по данным изготовителя двери (В.6.2); соседние помещения не считаются.", None),
    ("• Приложение В справочное; предпочтительны программы изготовителей ОП (В.1.3).", None),
    ("", None),
    ("Источники", BOLD),
    ("СП 3.13130.2026, приказ МЧС России от 26.02.2026 № 133: https://www.garant.ru/products/ipo/prime/doc/413717288/", None),
    ("Методика (документ): https://claude.ai/artifact/FgrxXfofSqPrp1YxfQidue", None),
]
for i, (t, fn) in enumerate(lines, 1):
    c = wt.cell(i, 1, t); c.font = fn or f(); c.alignment = Alignment(wrap_text=True, vertical="top")
wt.column_dimensions["A"].width = 140

# ---------------- Методика памятки «Стрелец» ----------------
wp = wb.create_sheet("Шаг Стрелец", 2)
wp["A1"] = "Шаг размещения речевых ОП по методике памятки «Аврора-ДТО-ПРО» (В.7.4 + шум по СП 51.13330)"; wp["A1"].font = H1
wp["A2"] = ("Восстановленная методика: L_Aмакс = L_Aэкв + 15; шум в октавах 500–2000 Гц = L_Aмакс − K; L_треб = шум в октаве + 15 дБ (В.7.4); "
            "r = 10^((L_1м − L_треб)/20) с округлением вниз; шаг = 2·r. При K = 12 дБ и 86 дБА на 1 м таблица памятки воспроизводится полностью. Эквивалентная запись: L_треб = L_Aэкв + 15 (п. 6.8.2), запас изготовителя 3 дБ (15 + 15 − 12 = 18 = 15 + 3). Ни K, ни 3 дБ в СП нет. Заполняйте жёлтые ячейки.")
wp["A2"].font = f(italic=True, color="595959")

wp["A4"] = "Параметры"; wp["A4"].font = BOLD
pin = [("PDEV", "Оповещатель", "Аврора-ДТО-ПРО (ИП 212/101-158-A1R)", "", "Выбор из таблицы оповещателей ниже"),
       ("PDLMAX", "L_Aмакс − L_Aэкв (СП 51.13330)", 15, "дБ", "Так в памятке: 50/65, 55/70, 60/75"),
       ("PRES", "Превышение над шумом (В.7.4)", 15, "дБ", "В.7.4: не менее 15 дБ"),
       ("PKOCT", "K: октавный шум ниже L_Aмакс на", 12, "дБ", "Неявное допущение памятки (подобрано по её цифрам); 12 дБ эквивалентно L_треб = L_Aэкв + 15 с запасом 3 дБ; 0 — сравнение с L_Aмакс (жёстче СП)"),
       ("PRND", "Округление расстояния вниз до", 0.5, "м", "В памятке округлено вниз (7,94 → 7; 4,47 → 4; 2,51 → 2,5)"),
       ("P_L1M", "УЗД оповещателя на 1 м (из таблицы)", None, "дБ", "Подставляется автоматически"),
       ("PDIR", "Направленность (из таблицы)", None, "", "Подставляется автоматически")]
r = 5
for key, label, val, unit, note in pin:
    wp.cell(r, 1, label).font = f(); wp.cell(r, 3, unit).font = f(); wp.cell(r, 4, note).font = f(color="595959")
    c = wp.cell(r, 2, val); c.border = BOX; c.alignment = Alignment(horizontal="center", wrap_text=True)
    if val is None:
        c.font = f()
    else:
        c.font = BLUE; c.fill = YEL
    name(key, f"'Шаг Стрелец'!$B${r}")
    r += 1
wp["B10"] = "=VLOOKUP(PDEV,DEV_TBL,2,FALSE)"; wp["B11"] = "=VLOOKUP(PDEV,DEV_TBL,3,FALSE)"

# results table
T0 = 14
wp.cell(T0 - 1, 1, "Расчёт по уровням шума").font = BOLD
th = ["L_Aэкв, дБА", "L_Aмакс, дБА", "L_треб, дБА", "r расчётное, м", "r принятое, м", "Шаг, м",
      "УЗД на r, дБА", "6.8.2 слышимость", "6.11.3 шум ≤ 65", "6.11.3 шаг ≤ 6/12 м", "В.7.4 r ≤ 8 м", "В.7.4 шаг ≤ 16 м"]
for i, h in enumerate(th, 1):
    c = wp.cell(T0, i, h); c.font = BOLD; c.fill = SUB; c.border = BOX; c.alignment = CENTER
wp.row_dimensions[T0].height = 30
for k, ln in enumerate([40, 45, 50, 55, 60, 65]):
    R = T0 + 1 + k
    c = wp.cell(R, 1, ln); c.font = BLUE; c.fill = YEL
    fm = {2: f"=A{R}+PDLMAX", 3: f"=B{R}-PKOCT+PRES", 4: f"=10^((P_L1M-C{R})/20)", 5: f"=FLOOR(D{R},PRND)", 6: f"=2*E{R}",
          7: f"=P_L1M-20*LOG10(MAX(1,E{R}))",
          8: f'=IF(G{R}>=MAX(65,A{R}+15),"Да","Нет")',
          9: f'=IF(A{R}<=N_INT_NOISE,"Да","Нет")',
          10: f'=IF(F{R}<=IF(PDIR="Двунаправленный",N_STEP2,N_STEP1),"Да","Нет")',
          11: f'=IF(E{R}<=N_B74R,"Да","Нет")',
          12: f'=IF(F{R}<=N_B74STEP,"Да","Нет")'}
    for col, v in fm.items():
        wp.cell(R, col, v)
    for col in range(1, 13):
        c = wp.cell(R, col); c.border = BOX; c.alignment = Alignment(horizontal="center")
        if col > 1: c.font = f()
        if col in (4, 5, 6, 7): c.number_format = "0.0"
rr_ = f"H{T0+1}:L{T0+6}"
wp.conditional_formatting.add(rr_, CellIsRule(operator="equal", formula=['"Да"'], fill=GREEN_F))
wp.conditional_formatting.add(rr_, CellIsRule(operator="equal", formula=['"Нет"'], fill=RED_F))
wp.cell(T0 + 7, 1, "Рекомендуемый шаг: не больше столбца «Шаг» и не больше 6 м (однонаправленные) / 12 м (двунаправленные) по п. 6.11.3.").font = f(italic=True, color="595959")
for k in range(6):
    R = T0 + 1 + k
    wp.cell(R, 13, f'=MIN(F{R},IF(PDIR="Двунаправленный",N_STEP2,N_STEP1),N_B74STEP)').number_format = "0.0"
    wp.cell(R, 13).font = BOLD; wp.cell(R, 13).border = BOX; wp.cell(R, 13).alignment = Alignment(horizontal="center")
c = wp.cell(T0, 13, "Шаг с учётом 6.11.3, м"); c.font = BOLD; c.fill = SUB; c.border = BOX; c.alignment = CENTER

# check of the memo table
C0 = T0 + 11
wp.cell(C0, 1, "Проверка таблицы памятки (обратный расчёт)").font = BOLD
ch = ["L_Aэкв, дБА", "L_Aмакс, дБА", "Расстояние по памятке, м", "Шаг по памятке, м", "Нужный УЗД на 1 м, дБ", "Запас при выбранном ОП, дБ", "Нужный УЗД на 1 м по п. 6.8.2 (L_Aэкв+15), дБ"]
for i, h in enumerate(ch, 1):
    c = wp.cell(C0 + 1, i, h); c.font = BOLD; c.fill = SUB; c.border = BOX; c.alignment = CENTER
wp.row_dimensions[C0 + 1].height = 30
for k, (ln, lm, d, s) in enumerate([(50, 65, 7, 14), (55, 70, 4, 8), (60, 75, 2.5, 5)]):
    R = C0 + 2 + k
    for col, v in ((1, ln), (2, lm), (3, d), (4, s)):
        wp.cell(R, col, v).font = f()
    wp.cell(R, 5, f"=B{R}-PKOCT+PRES+20*LOG10(C{R})").number_format = "0.0"
    wp.cell(R, 6, f"=P_L1M-E{R}").number_format = "0.0"
    wp.cell(R, 7, f"=A{R}+PRES+20*LOG10(C{R})").number_format = "0.0"
    for col in range(1, 8):
        wp.cell(R, col).border = BOX; wp.cell(R, col).alignment = Alignment(horizontal="center")
        if col > 4: wp.cell(R, col).font = f()
wp.conditional_formatting.add(f"F{C0+2}:F{C0+4}", CellIsRule(operator="lessThan", formula=["0"], fill=RED_F))
wp.conditional_formatting.add(f"F{C0+2}:F{C0+4}", CellIsRule(operator="greaterThanOrEqual", formula=["0"], fill=GREEN_F))
wp.cell(C0 + 5, 1, "При K = 12 дБ все три строки укладываются в 86 дБА на 1 м (п. 3.11 памятки). Буквально по п. 6.8.2 (L_Aэкв + 15 дБ) нужно 82–83 дБА на 1 м, т. е. радиусы памятки подтверждаются с запасом около 3 дБ. Вывод «завышены в 4 раза» (K = 0) верен только при сравнении с L_Aмакс, чего СП не требует.").font = f(italic=True, color="595959")

# devices
D0 = C0 + 8
wp.cell(D0, 1, "Таблица оповещателей «Стрелец» (данные из ТД изготовителя)").font = BOLD
dh = ["Модель", "Макс. УЗД на 1 м, дБ", "Направленность", "Источник / примечание"]
for i, h in enumerate(dh, 1):
    c = wp.cell(D0 + 1, i, h); c.font = BOLD; c.fill = SUB; c.border = BOX; c.alignment = CENTER
devs = [("Аврора-ДТО-ПРО (ИП 212/101-158-A1R)", 86, "Однонаправленный", "Памятка АДГЕ.425238.043 Д5 ред. 1.2, п. 3.11: более 86 дБА на 1 м (на 3 м — более 76 дБА)")]
devs += [("Орфей-ПРО", 90, "Однонаправленный", "Памятка СТФВ.425542.008 Д5 ред. 2.1: синус 1 кГц более 90 дБ, речь более 87 дБА на 1 м"),
         ("Орфей-РР-V10-ПРО исп. Л", 98, "Двунаправленный", "Руководство, п. 1.4: синус 1 кГц более 98 дБ(А), речь более 97 дБ(А) на 1 м")]
devs += [(f"Оповещатель {i} (заполнить)", None, "Однонаправленный", "") for i in range(4, 13)]
for k, row in enumerate(devs):
    R = D0 + 2 + k
    for col, v in enumerate(row, 1):
        c = wp.cell(R, col, v); c.font = BLUE; c.fill = YEL; c.border = BOX
dend = D0 + 1 + len(devs)
name("DEV_TBL", f"'Шаг Стрелец'!$A${D0+2}:$C${dend}"); name("DEV_NAMES", f"'Шаг Стрелец'!$A${D0+2}:$A${dend}")
d1 = DataValidation(type="list", formula1="=DEV_NAMES"); wp.add_data_validation(d1); d1.add("B5")
d2 = DataValidation(type="list", formula1='"Однонаправленный,Двунаправленный"'); wp.add_data_validation(d2); d2.add(f"C{D0+2}:C{dend}")
for col, w in zip("ABCDEFGHIJKLM", [40, 30, 14, 40, 14, 14, 12, 12, 12, 14, 12, 12, 14]):
    wp.column_dimensions[col].width = w

# ---------------- Радиус зоны оповещения ----------------
wz = wb.create_sheet("Радиус зоны", 3)
wz["A1"] = "Радиус зоны оповещения речевых ОП «Стрелец» по СП 3.13130.2026"; wz["A1"].font = H1
wz["A2"] = ("r = 10^((L_1м + ослабление − ΔL − L_треб)/20) по (В.1)–(В.2) вдоль луча; радиус на полу (на высоте h_рт) R = √(r² − Δh²). "
            "Жёлтые ячейки — ввод. Строки оповещателей можно добавлять в пустые строки таблицы.")
wz["A2"].font = f(italic=True, color="595959")
zin = [("Z_CAT", "Категория помещения", "Прочее помещение", "", "Нормы — лист «Нормы»"),
       ("Z_LN", "L_Aэкв постоянного шума", 50, "дБА", "Замеры, задание или табл. В.1"),
       ("Z_DLM", "L_Aмакс − L_Aэкв", 15, "дБ", "Как в памятках «Стрелец» (СП 51.13330)"),
       ("Z_K", "K: октавный шум ниже L_Aмакс на", 12, "дБ", "Допущение памяток «Стрелец»; 12 дБ ≡ L_Aэкв + 15 + запас 3 дБ; 0 — сравнение с L_Aмакс (жёстче СП)"),
       ("Z_HRT", "Высота расчётной точки h_рт", 1.5, "м", "п. 6.8.2, 6.11.1"),
       ("Z_A", "Длина помещения (для подсчёта ОП)", 18, "м", "Необязательно"),
       ("Z_B", "Ширина помещения (для подсчёта ОП)", 12, "м", "Необязательно")]
r = 4
for key, label, val, unit, note in zin:
    wz.cell(r, 1, label).font = f(); wz.cell(r, 3, unit).font = f(); wz.cell(r, 4, note).font = f(color="595959")
    c = wz.cell(r, 2, val); c.font = BLUE; c.fill = YEL; c.border = BOX; c.alignment = Alignment(horizontal="center")
    name(key, f"'Радиус зоны'!$B${r}"); r += 1
dz = DataValidation(type="list", formula1="=CATS"); wz.add_data_validation(dz); dz.add("B4")
zc = [("Z_LTR", "L_треб по слышимости (6.8.2 / 6.9.1)", "=IF(Z_LN>N_NOISE85,105,MAX(VLOOKUP(Z_CAT,TBL_NORM,2,FALSE),Z_LN+VLOOKUP(Z_CAT,TBL_NORM,3,FALSE)))", "дБА"),
      ("Z_LTI", "L_треб по разборчивости (6.11.3)", "=Z_LN+N_INT_SNR", "дБА"),
      ("Z_LTB", "L_треб по В.7.4 (методика памяток)", "=Z_LN+Z_DLM-Z_K+N_B74SNR", "дБА"),
      ("Z_LUP", "Верхний предел УЗД", "=VLOOKUP(Z_CAT,TBL_NORM,4,FALSE)", "дБА")]
r += 1
for key, label, fml, unit in zc:
    wz.cell(r, 1, label).font = BOLD; c = wz.cell(r, 2, fml); c.font = BOLD; c.border = BOX; c.number_format = "0.0"
    c.alignment = Alignment(horizontal="center"); wz.cell(r, 3, unit).font = f()
    name(key, f"'Радиус зоны'!$B${r}"); r += 1
wz.cell(r, 1, "Шум выше 65 дБА: по п. 6.11.3 разборчивость не обеспечивается, радиус разборчивости = 0.").font = f(italic=True, color="595959")

H0 = r + 2
zh = ["Оповещатель", "Монтаж", "Направленность", "УЗД речи на 1 м, дБА", "Макс. УЗД на 1 м (синус), дБ", "Ослабление громкости, дБ",
      "ΔL направленности на границе, дБ", "Высота установки h_оп, м", "Δh, м",
      "R слышимость 6.8.2, м", "R разборчивость 6.11.3, м", "R по В.7.4, м",
      "R по СП (6.8.2 + 6.11.3), м", "R с учётом шага 6.11.3, м", "Рекомендуемый R, м", "Шаг, м", "Площадь зоны, м²",
      "Кол-во ОП на помещение", "Верхний предел", "Источник данных"]
for i, h in enumerate(zh, 1):
    c = wz.cell(H0, i, h); c.font = BOLD; c.fill = SUB; c.border = BOX; c.alignment = CENTER
wz.row_dimensions[H0].height = 58
zdev = [("Аврора-ДТО-ПРО (ИП 212/101-158-A1R)", "Потолок", "Однонаправленный", 86, 86, 0, 0, 3.0, "Памятка АДГЕ.425238.043 Д5 ред. 1.2, п. 3.11"),
        ("Орфей-ПРО", "Потолок", "Однонаправленный", 87, 90, 0, 0, 3.0, "Памятка СТФВ.425542.008 Д5 ред. 2.1, разд. 3"),
        ("Орфей-РР-V10-ПРО исп. Л", "Стена", "Двунаправленный", 97, 98, 0, 0, 2.5, "Руководство, п. 1.4; диаграмма: ≈ 0…−5 дБ в полусфере")]
zdev += [("", "Потолок", "Однонаправленный", None, None, 0, 0, 3.0, "")] * 5
for k, row in enumerate(zdev):
    R = H0 + 1 + k
    for col, v in zip((1, 2, 3, 4, 5, 6, 7, 8, 20), row):
        c = wz.cell(R, col, v); c.font = BLUE; c.fill = YEL; c.border = BOX
        c.alignment = Alignment(horizontal="center", wrap_text=True)
    def g(expr): return f'=IF(OR($A{R}="",$D{R}=""),"",{expr})'
    rr_ = lambda lvl, req: f"10^(({lvl}+F{R}-G{R}-{req})/20)"
    hor = lambda rexp: f"SQRT(MAX(0,({rexp})^2-I{R}^2))"
    fz = {9: g(f"MAX(0,H{R}-Z_HRT)"),
          10: g(hor(rr_(f"D{R}", "Z_LTR"))),
          11: g(f"IF(Z_LN>N_INT_NOISE,0,{hor(rr_(f'D{R}', 'Z_LTI'))})"),
          12: g(hor(f"MIN(N_B74R,{rr_(f'E{R}', 'Z_LTB')})")),
          13: g(f"MIN(J{R},K{R})"),
          14: g(f'MIN(M{R},IF(C{R}="Двунаправленный",N_STEP2,N_STEP1)/2)'),
          15: g(f"MIN(N{R},L{R})"),
          16: g(f"2*O{R}"),
          17: g(f'IF(B{R}="Стена",PI()*O{R}^2/2,PI()*O{R}^2)'),
          18: g(f'IF(O{R}<=0,"—",IF(B{R}="Стена",2*CEILING(Z_A/P{R},1),CEILING(Z_A/(O{R}*SQRT(2)),1)*CEILING(Z_B/(O{R}*SQRT(2)),1)))'),
          19: g(f'IF(D{R}+F{R}-20*LOG10(MAX(1,I{R}))<=Z_LUP,"Да","Нет")')}
    for col, v in fz.items():
        c = wz.cell(R, col, v); c.font = f(); c.border = BOX; c.alignment = Alignment(horizontal="center")
        if col in range(9, 18): c.number_format = "0.0"
    wz.cell(R, 15).font = BOLD
    for col in (9, 10, 11, 12, 13, 14, 16, 17): pass
last_z = H0 + len(zdev)
for col in (2, 3):
    dvz = DataValidation(type="list", formula1='"Потолок,Стена"' if col == 2 else '"Однонаправленный,Двунаправленный"')
    wz.add_data_validation(dvz); dvz.add(f"{CL(col)}{H0+1}:{CL(col)}{last_z}")
dvf = DataValidation(type="list", formula1='"0,-10,-12,-15,-18"'); wz.add_data_validation(dvf); dvf.add(f"F{H0+1}:F{last_z}")
wz.conditional_formatting.add(f"S{H0+1}:S{last_z}", CellIsRule(operator="equal", formula=['"Да"'], fill=GREEN_F))
wz.conditional_formatting.add(f"S{H0+1}:S{last_z}", CellIsRule(operator="equal", formula=['"Нет"'], fill=RED_F))
wz.conditional_formatting.add(f"O{H0+1}:O{last_z}", CellIsRule(operator="lessThanOrEqual", formula=["0"], fill=RED_F))
notes = [
    "Как читать: «R по СП» — радиус, где выполняются слышимость (6.8.2) и разборчивость (6.11.3) от одного ОП. «R с учётом шага» дополнительно ограничен половиной шага 6.11.3 (3 м / 6 м) — нужен, когда ОП в помещении несколько.",
    "«Рекомендуемый R» = min(R с учётом шага; R по В.7.4). В.7.4 — справочные предварительные ограничения: до слушателя ≤ 8 м и превышение над шумом ≥ 15 дБ (у «Стрелец» — по L_Aмакс − K).",
    "Слышимость и разборчивость считаются по уровню речи (он ниже синуса), В.7.4 — по максимальному УЗД (синус 1 кГц), как в памятках изготовителя.",
    "ΔL направленности: 0 — ОП без паспортной диаграммы, оценка по оси; при известном только угле раскрыва по В.4.2 ставьте 6 дБ. Для Орфей-РР-V10 по диаграмме в полусфере ≈ 0…−5 дБ.",
    "Кол-во ОП: потолочные — квадратная сетка с шагом R·√2 (круги перекрывают помещение); настенные двунаправленные — по 2 ряда вдоль длины с шагом 2R. Это оценка, проверять планом на листе «Расчёт».",
]
for k, t in enumerate(notes):
    c = wz.cell(last_z + 2 + k, 1, t); c.font = f(color="595959")
for col, w in zip("ABCDEFGHIJKLMNOPQRST", [40, 14, 18, 11, 12, 12, 12, 11, 8, 11, 12, 10, 12, 12, 12, 9, 10, 10, 10, 40]):
    wz.column_dimensions[col].width = w
wz.freeze_panes = wz.cell(H0 + 1, 2)
name("ZDEV_TBL", f"'Радиус зоны'!$A${H0+1}:$E${last_z}"); name("ZDEV_NAMES", f"'Радиус зоны'!$A${H0+1}:$A${last_z}")
name("ZDEV_SRC", f"'Радиус зоны'!$T${H0+1}:$T${last_z}")
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "report.py"), encoding="utf-8").read())

wb.calculation.fullCalcOnLoad = True
wb.save(OUT)
print("saved")
