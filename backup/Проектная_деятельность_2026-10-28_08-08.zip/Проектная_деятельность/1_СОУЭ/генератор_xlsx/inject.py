# Вписывает кэшированные значения формул (из пересчитанной LibreOffice копии) в файл openpyxl,
# не трогая оформление. Использование: python3 inject.py RAW.xlsx RECALC.xlsx OUT.xlsx
import sys, re, zipfile
from xml.sax.saxutils import escape
from openpyxl import load_workbook
raw, rec, out = sys.argv[1:4]
vals = load_workbook(rec, data_only=True)
zin = zipfile.ZipFile(raw)
wbx = zin.read("xl/workbook.xml").decode()
rels = zin.read("xl/_rels/workbook.xml.rels").decode()
rid2t = dict(re.findall(r'Id="(rId\d+)"[^>]*Target="/?(?:xl/)?([^"]+)"', rels)) or {}
for m in re.finditer(r'<Relationship [^>]*>', rels):
    t = re.search(r'Target="/?(?:xl/)?([^"]+)"', m.group()).group(1); i = re.search(r'Id="([^"]+)"', m.group()).group(1); rid2t[i] = t
path2name = {"xl/" + rid2t[rid]: name for name, rid in re.findall(r'<sheet [^>]*name="([^"]+)"[^>]*r:id="([^"]+)"', wbx)}
cnt = 0
def fill(xml, ws):
    global cnt
    def rep(m):
        global cnt
        ref, attrs, f = m.group(1), m.group(2), m.group(3)
        v = ws[ref].value
        attrs = re.sub(r'\s+t="[^"]*"', "", attrs)
        if v is None: return m.group(0)
        cnt += 1
        if isinstance(v, bool): return f'<c r="{ref}"{attrs} t="b">{f}<v>{int(v)}</v></c>'
        if isinstance(v, (int, float)): return f'<c r="{ref}"{attrs}>{f}<v>{repr(float(v)) if isinstance(v,float) else v}</v></c>'
        s = str(v)
        if s.startswith("#"): return f'<c r="{ref}"{attrs} t="e">{f}<v>{escape(s)}</v></c>'
        return f'<c r="{ref}"{attrs} t="str">{f}<v>{escape(s)}</v></c>'
    return re.sub(r'<c r="([A-Z]+\d+)"([^>]*)>(<f>.*?</f>)<v\s*/?>(?:</v>)?</c>', rep, xml)
zout = zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED)
for it in zin.infolist():
    data = zin.read(it.filename)
    if it.filename in path2name:
        data = fill(data.decode(), vals[path2name[it.filename]]).encode()
    zout.writestr(it, data)
zout.close(); print("cached values:", cnt, "sheets:", list(path2name.values()))
