import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Arc, Rectangle, Circle
plt.rcParams["font.family"] = "DejaVu Sans"
import os; D = os.path.dirname(os.path.abspath(__file__)) + "/"
# Fig 1: side view
fig, ax = plt.subplots(figsize=(7.5, 3.6), dpi=150)
ax.plot([-1, 9], [0, 0], color="k", lw=2); ax.plot([-1, 9], [3, 3], color="k", lw=2)
ax.text(8.9, -0.25, "пол", ha="right", fontsize=9); ax.text(8.9, 3.1, "потолок", ha="right", fontsize=9)
ax.add_patch(Rectangle((-0.25, 2.85), 0.5, 0.15, color="#c00000")); ax.text(-0.95, 2.55, "ОП", fontsize=10, color="#c00000", weight="bold")
ax.plot([-1, 9], [1.5, 1.5], color="#7f7f7f", ls="--", lw=1); ax.text(2.0, 1.58, "расчётная плоскость h_рт", fontsize=8, color="#595959")
ax.plot([0, 7], [2.85, 1.5], color="#1f4e78", lw=1.6); ax.plot([7], [1.5], "o", color="#1f4e78"); ax.text(7.1, 1.6, "РТ — наиболее удалённая точка", fontsize=8.5, color="#1f4e78")
ax.text(3.5, 2.35, "r₂", fontsize=12, color="#1f4e78")
ax.plot([0, 0], [2.85, 1.5], color="#595959", lw=1, ls=":")
ax.annotate("", xy=(-0.35, 1.5), xytext=(-0.35, 2.85), arrowprops=dict(arrowstyle="<->", color="#595959")); ax.text(-0.85, 2.05, "Δh", fontsize=11)
ax.annotate("", xy=(0, 1.3), xytext=(7, 1.3), arrowprops=dict(arrowstyle="<->", color="#595959")); ax.text(3.3, 1.05, "d (по плану)", fontsize=10)
ax.annotate("", xy=(8.4, 0), xytext=(8.4, 2.85), arrowprops=dict(arrowstyle="<->", color="#595959")); ax.text(8.5, 1.0, "h_оп", fontsize=10)
ax.annotate("", xy=(-0.6, 0), xytext=(-0.6, 1.5), arrowprops=dict(arrowstyle="<->", color="#595959")); ax.text(-0.55, 0.6, "h_рт", fontsize=10)
ax.add_patch(Arc((0, 2.85), 2.2, 2.2, theta1=270, theta2=270 + 79, color="#c00000")); ax.text(0.45, 2.15, "θ", fontsize=12, color="#c00000")
ax.text(0.05, 1.62, "ось ОП", fontsize=8, color="#595959")
ax.set_xlim(-1.1, 9.2); ax.set_ylim(-0.4, 3.4); ax.axis("off")
ax.set_title("Рисунок 1 — Расчётная схема (разрез): r₂ = √(d² + Δh²), θ = arctg(d / Δh)", fontsize=10)
fig.tight_layout(); fig.savefig(D + "fig1.png"); plt.close(fig)
# Fig 2: plan grid
fig, ax = plt.subplots(figsize=(7.5, 4.2), dpi=150)
a, b, nx, ny = 12, 8, 3, 2
cx, cy = a / nx, b / ny
ax.add_patch(Rectangle((0, 0), a, b, fill=False, lw=2))
for i in range(1, nx): ax.plot([i * cx] * 2, [0, b], color="#bfbfbf", ls="--", lw=0.8)
for j in range(1, ny): ax.plot([0, a], [j * cy] * 2, color="#bfbfbf", ls="--", lw=0.8)
for i in range(nx):
    for j in range(ny):
        x, y = (i + .5) * cx, (j + .5) * cy
        ax.add_patch(Circle((x, y), 2.9, fill=True, alpha=0.12, color="#2e75b6"))
        ax.plot(x, y, "s", color="#c00000", ms=7)
x0, y0 = .5 * cx, .5 * cy
ax.plot([x0, cx], [y0, cy], color="#1f4e78", lw=1.6); ax.plot(cx, cy, "o", color="#1f4e78")
ax.text(x0 + .3, y0 + 1.2, "d", fontsize=12, color="#1f4e78")
ax.annotate("", xy=(0, -0.5), xytext=(cx, -0.5), arrowprops=dict(arrowstyle="<->")); ax.text(cx / 2 - .3, -1.1, "c_x = a / n_x", fontsize=9)
ax.annotate("", xy=(-0.5, 0), xytext=(-0.5, cy), arrowprops=dict(arrowstyle="<->")); ax.text(-1.9, cy / 2, "c_y", fontsize=9)
ax.text(a + .2, b - .5, "■ ОП", color="#c00000", fontsize=9); ax.text(a + .2, b - 1.3, "● РТ", color="#1f4e78", fontsize=9)
ax.text(a + .2, b - 2.1, "зона оповещения R", color="#2e75b6", fontsize=9)
ax.set_xlim(-2.2, a + 4); ax.set_ylim(-1.5, b + .5); ax.set_aspect("equal"); ax.axis("off")
ax.set_title("Рисунок 2 — Размещение ОП по сетке n_x × n_y (план): d = √((c_x/2)² + (c_y/2)²)", fontsize=10)
fig.tight_layout(); fig.savefig(D + "fig2.png"); plt.close(fig)
print("ok")
