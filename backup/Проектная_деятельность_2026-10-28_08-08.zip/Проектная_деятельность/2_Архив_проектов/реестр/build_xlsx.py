import json, sys, re, collections, os
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'addr.py'), encoding='utf-8').read())
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils import get_column_letter as CL
from openpyxl.formatting.rule import FormulaRule

D = json.load(open(sys.argv[1]))
OUT = sys.argv[2]
R = D['records']


def year_flag(r):
    fy = re.match(r'(\d{4})', r['proj_folder'].split('\\')[2] if r['proj_folder'].count('\\') >= 2 else '')
    if r['year_src'] == 'титул' and fy and r['year'] and r['year'] < int(fy.group(1)) - 6:
        return 'год по титулу намного раньше года папки'
    return ''


def nat(s):
    return [int(x) if x.isdigit() else x for x in re.split(r'(\d+)', s)]


R.sort(key=lambda r: (r['year'] or 0, nat(r['shifr'])))

ORG_COLS = [('designer', 'Проектировщик'), ('customer', 'Заказчик'), ('genproj', 'Генпроектировщик'), ('genpodr', 'Генподрядчик'), ('other_orgs', 'Другие организации')]
PPL_COLS = ['ГИП', 'ГАП', 'Ген. директор', 'Директор', 'Рук. ПБ', 'Нач. отдела', 'Гл. специалист', 'Разработал', 'Проверил', 'Н. контроль', 'Утвердил']
HEAD = (['№', 'Шифр', 'Название проекта (объект)', 'Проектируемая система', 'Стадия', 'Год', 'Год: источник'] + [h for _, h in ORG_COLS] + PPL_COLS +
        ['№ заказа (папка)', 'Путь к проекту', 'Файл-источник', 'Файлов найдено', 'Другие шифры на титуле', 'Требует проверки'])
WID = [6, 24, 60, 42, 7, 7, 14, 26, 26, 22, 18, 30] + [16] * len(PPL_COLS) + [10, 55, 55, 9, 22, 40]

NAVY = '1F3864'
hfont = Font(bold=True, color='FFFFFF', size=10)
hfill = PatternFill('solid', fgColor=NAVY)
thin = Side(style='thin', color='BFBFBF')
wrap = Alignment(wrap_text=True, vertical='top')
link = Font(color='0563C1', underline='single', size=9)

wb = Workbook()
ws = wb.active
ws.title = 'Проекты'
ws['A1'] = 'Реестр проектов из архива \\\\192.168.100.8\\project (Z:\\Архив)'
ws['A1'].font = Font(bold=True, size=14, color=NAVY)
ws['A2'] = ('Одна строка — один шифр. Данные взяты из текста титулов, обложек, общих данных, записок и спецификаций; если на титуле чего-то не было, '
            'название берётся из имени папки, год — из папки архива (см. столбец «Требует проверки»). Фильтры — стрелки в заголовках, быстрый поиск — лист «Поиск».')
ws['A2'].font = Font(italic=True, size=9, color='595959')
ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=12)
ws.row_dimensions[2].height = 30
ws['A2'].alignment = Alignment(wrap_text=True, vertical='top')
HR = 4
for j, h in enumerate(HEAD, 1):
    c = ws.cell(HR, j, h)
    c.font = hfont; c.fill = hfill; c.alignment = Alignment(wrap_text=True, vertical='center', horizontal='center')
    ws.column_dimensions[CL(j)].width = WID[j - 1]
ws.row_dimensions[HR].height = 32
for i, r in enumerate(R, 1):
    flags = r['flags']
    vals = ([i, r['shifr'], r['name'], r['system'], r['stage'], r['year'], r['year_src']] + [r[k] for k, _ in ORG_COLS] +
            [r['people'].get(p, '') for p in PPL_COLS] + [r['order'], r['path'], r['best_file'], r['nfiles'], r['others'], flags])
    row = HR + i
    for j, v in enumerate(vals, 1):
        c = ws.cell(row, j, v if v != '' else None)
        c.alignment = wrap
        c.font = Font(size=9)
    pc = HEAD.index('Путь к проекту') + 1
    fc = HEAD.index('Файл-источник') + 1
    ws.cell(row, pc).hyperlink = r['path']; ws.cell(row, pc).font = link
    ws.cell(row, fc).hyperlink = r['best_file']; ws.cell(row, fc).font = link
last = HR + len(R)
ncol = len(HEAD)
tab = Table(displayName='tblProjects', ref=f'A{HR}:{CL(ncol)}{last}')
tab.tableStyleInfo = TableStyleInfo(name='TableStyleLight9', showRowStripes=True)
ws.add_table(tab)
ws.freeze_panes = ws.cell(HR + 1, 3)
fl = CL(HEAD.index('Требует проверки') + 1)
ws.conditional_formatting.add(f'{fl}{HR+1}:{fl}{last}', FormulaRule(formula=[f'ISNUMBER(SEARCH("шифр найден",{fl}{HR+1}))'], fill=PatternFill('solid', fgColor='FFF2CC')))

# скрытый столбец-помощник для поиска
hc = ncol + 2
H = CL(hc)
ws.cell(HR, hc, 'служ.')
text_cols = [CL(j) for j in range(2, ncol + 1)]
for i in range(len(R)):
    row = HR + 1 + i
    concat = '&" "&'.join(f'{c}{row}' for c in text_cols)
    ws.cell(row, hc, f'=IF(Поиск!$C$3="","",IF(ISNUMBER(SEARCH(Поиск!$C$3,{concat})),ROW(),""))')
ws.column_dimensions[H].hidden = True

# Поиск
sp = wb.create_sheet('Поиск', 0)
sp['B1'] = 'Поиск по реестру проектов'
sp['B1'].font = Font(bold=True, size=14, color=NAVY)
sp['B3'] = 'Введите слово или часть шифра:'
sp['B3'].font = Font(bold=True)
sp['C3'].fill = PatternFill('solid', fgColor='FFF2CC')
sp['C3'].border = Border(left=Side(style='medium', color=NAVY), right=Side(style='medium', color=NAVY), top=Side(style='medium', color=NAVY), bottom=Side(style='medium', color=NAVY))
sp['C3'].font = Font(size=12, bold=True)
sp['E3'] = 'Найдено:'
sp['E3'].alignment = Alignment(horizontal='right')
sp['F3'] = f'=COUNT(Проекты!{H}:{H})'
sp['F3'].font = Font(bold=True)
sp['B4'] = 'Ищет по всем столбцам: шифр, название, система, организации, фамилии, путь. Показываются первые 300 совпадений; полный отбор — фильтрами на листе «Проекты».'
sp['B4'].font = Font(italic=True, size=9, color='595959')
SHOW = ['№', 'Шифр', 'Название проекта (объект)', 'Проектируемая система', 'Год', 'Проектировщик', 'Заказчик', 'ГИП', 'Разработал', 'Путь к проекту']
SW = [6, 24, 60, 40, 7, 26, 26, 18, 18, 60]
for j, h in enumerate(SHOW, 2):
    c = sp.cell(6, j, h); c.font = hfont; c.fill = hfill; c.alignment = Alignment(wrap_text=True, horizontal='center')
    sp.column_dimensions[CL(j)].width = SW[j - 2]
sp.column_dimensions['A'].width = 2
for k in range(1, 301):
    row = 6 + k
    for j, h in enumerate(SHOW, 2):
        col = CL(HEAD.index(h) + 1)
        sp.cell(row, j, f'=IFERROR(INDEX(Проекты!{col}:{col},SMALL(Проекты!${H}:${H},{k}))&"","")')
        sp.cell(row, j).font = Font(size=9)
        sp.cell(row, j).alignment = Alignment(vertical='top', wrap_text=(h in ('Название проекта (объект)', 'Проектируемая система')))
sp.freeze_panes = 'A7'

# По объектам: одна строка на папку объекта, списки в ячейке друг под другом
sb = wb.create_sheet('По объектам', 1)
OB_HEAD = ['№', 'Год', 'Название объекта', 'Шифры', 'Проектируемые системы', 'Организации', 'Участники', 'Путь', 'Адрес / местоположение']
OB_W = [6, 11, 50, 26, 42, 40, 24, 50, 45]
sb['A1'] = 'Объекты архива: все шифры, системы, организации и участники по каждой папке заказа'
sb['A1'].font = Font(bold=True, size=14, color=NAVY)
for j, h in enumerate(OB_HEAD, 1):
    c = sb.cell(3, j, h); c.font = hfont; c.fill = hfill; c.alignment = Alignment(wrap_text=True, vertical='center', horizontal='center')
    sb.column_dimensions[CL(j)].width = OB_W[j - 1]


def uniq(seq):
    out, seen = [], set()
    for x in seq:
        x = (x or '').strip()
        k = x.lower().replace('ё', 'е').replace(' ', '')
        if x and k not in seen:
            seen.add(k); out.append(x)
    return out


def surname_list(rs):
    best = {}
    order = []
    for r in rs:
        for role, names in r['people'].items():
            for n in names.split(', '):
                n = n.strip()
                if not n:
                    continue
                k = n.split()[0].lower().replace('ё', 'е')
                if k not in best:
                    order.append(k); best[k] = n
                elif len(n) > len(best[k]):
                    best[k] = n  # с инициалами полнее
    return [best[k] for k in order]


objs = collections.defaultdict(list)
for r in R:
    objs[r['proj_folder']].append(r)
for f, n in D['no_shifr']:
    objs.setdefault(f, [])
rows_ob = []
for f, rs in objs.items():
    folder = f.split('\\')[-1]
    fname = re.sub(r'^[_\s]*\d{3}(?:\s*,\s*\d{3})*[_\s]*', '', folder).replace('_', ' ').strip() or folder.strip('_ ')
    names = collections.Counter(r['name'] for r in rs if r['name'] and 'название по имени папки' not in r['flags'])
    # титулы в папке бывают скопированы из другого объекта: берём название, которое перекликается с именем папки
    STOPW = {'стадия', 'рабочая', 'рабочий', 'проект', 'корректировка', 'изменения', 'новый', 'старый', 'папка'}
    fw = {w[:5].lower() for w in re.findall(r'[А-Яа-яЁё]{4,}', fname) if w.lower() not in STOPW}
    def overlap(n):
        return len(fw & {w[:5].lower() for w in re.findall(r'[А-Яа-яЁё]{4,}', n)})
    if names:
        cand = sorted(names.items(), key=lambda x: (overlap(x[0]) > 0, x[1]), reverse=True)
        name = cand[0][0] if (overlap(cand[0][0]) > 0 or len(fw) < 2) else fname
    else:
        name = fname
    names_ok = [n for n in names if overlap(n) > 0 or len(fw) < 2] or list(names)
    ys = sorted({r['year'] for r in rs if r['year']})
    fy = f.split('\\')[2] if f.count('\\') >= 2 else ''
    year = (str(ys[0]) if len(ys) == 1 else '%d–%d' % (ys[0], ys[-1])) if ys else fy
    shifrs = sorted({r['shifr'] for r in rs}, key=nat)
    systems = uniq(r['system'] for r in sorted(rs, key=lambda r: nat(r['shifr'])))
    orgs = uniq(o for r in rs for o in [r['designer'], r['customer'], r['genproj'], r['genpodr']] + r['other_orgs'].split('; '))
    orgs = uniq(re.sub(r'«\s+', '«', re.sub(r'\s+»', '»', o)) for o in orgs)
    orgs = [o for o in orgs if not re.search(r'«\s*»|«\s*$', o)]
    ppl = surname_list(rs)
    tw = [(folder.replace('_', ' '), 5), (name, 4)] + [(n, 2) for n in names_ok] + [(r.get('addr_text', ''), 1) for r in rs if r['name'] in names_ok]
    rows_ob.append([ys[0] if ys else 9999, nat(folder), year, name, shifrs, systems, orgs, ppl, f, tw])
# улица не из имени папки и не из итогового названия, встречающаяся в 4+ разных папках, — скорее шаблон/ссылка, а не адрес объекта
tsc = collections.Counter(k for r in rows_ob for k in text_streets(r[-1]))
banned = {k for k, v in tsc.items() if v >= 4}
for r in rows_ob:
    r[-1] = locate(r[-1], r[3], banned)
rows_ob.sort(key=lambda x: (x[0], x[1]))
for i, (_, _, year, name, shifrs, systems, orgs, ppl, f, addr) in enumerate(rows_ob, 1):
    row = 3 + i
    vals = [i, year, name, '\n'.join(shifrs), '\n'.join(systems), '\n'.join(orgs), '\n'.join(ppl), f, addr]
    for j, v in enumerate(vals, 1):
        c = sb.cell(row, j, v if v != '' else None)
        c.alignment = Alignment(wrap_text=True, vertical='top')
        c.font = Font(size=9)
        c.border = Border(bottom=thin)
    sb.cell(row, 8).hyperlink = f; sb.cell(row, 8).font = link
    nlines = max(1, len(shifrs), len(systems), len(orgs), len(ppl))
    sb.row_dimensions[row].height = min(409, 12.5 * nlines + 3)
sb.auto_filter.ref = f'A3:I{3 + len(rows_ob)}'
sb.freeze_panes = 'D4'

# Объекты (папки заказов)
so = wb.create_sheet('Объекты')
byf = collections.defaultdict(list)
for r in R:
    byf[r['proj_folder']].append(r)
so.append(['№', '№ заказа', 'Папка объекта', 'Год папки', 'Шифров', 'Шифры', 'Путь'])
for c in so[1]:
    c.font = hfont; c.fill = hfill; c.alignment = Alignment(wrap_text=True, horizontal='center')
for i, (f, rs) in enumerate(sorted(byf.items(), key=lambda x: nat(x[0])), 1):
    name = f.split('\\')[-1]
    yr = f.split('\\')[2] if f.count('\\') >= 2 else ''
    od = re.search(r'^_?\s*(\d{3}(?:\s*,\s*\d{3})*)', name)
    so.append([i, od.group(1) if od else '', name.strip('_ '), yr, len(rs), ', '.join(sorted({r['shifr'] for r in rs}, key=nat)), f])
    so.cell(so.max_row, 7).hyperlink = f; so.cell(so.max_row, 7).font = link
for col, w in zip('ABCDEFG', [6, 10, 55, 11, 8, 80, 55]):
    so.column_dimensions[col].width = w
for row in so.iter_rows(min_row=2):
    for c in row:
        c.alignment = wrap
        if c.column != 7:
            c.font = Font(size=9)
so.auto_filter.ref = f'A1:G{so.max_row}'
so.freeze_panes = 'A2'

# Без шифра
sn = wb.create_sheet('Без шифра')
sn.append(['№', 'Папка объекта', 'Файлов-кандидатов', 'Путь'])
for c in sn[1]:
    c.font = hfont; c.fill = hfill
for i, (f, n) in enumerate(D['no_shifr'], 1):
    sn.append([i, f.split('\\')[-1].strip('_ '), n, f])
    sn.cell(sn.max_row, 4).hyperlink = f; sn.cell(sn.max_row, 4).font = link
for col, w in zip('ABCD', [6, 60, 12, 70]):
    sn.column_dimensions[col].width = w
sn.auto_filter.ref = f'A1:D{sn.max_row}'

# Сканы без текста
ss = wb.create_sheet('Сканы PDF')
ss.append(['№', 'Файл', 'Путь'])
for c in ss[1]:
    c.font = hfont; c.fill = hfill
for i, p in enumerate(D.get('scans', []), 1):
    ss.append([i, p.split('\\')[-1], p])
    ss.cell(ss.max_row, 3).hyperlink = p; ss.cell(ss.max_row, 3).font = link
ss.column_dimensions['B'].width = 50; ss.column_dimensions['C'].width = 100

# Справка
sh = wb.create_sheet('Справка')
info = [
    ('Как собран реестр', ''),
    ('Источник', f"Выборка titles_extract_2026-10-23_10-21: {D['total']} файлов-кандидатов (pdf, doc, docx, dwg с «титул», «обложка», «общие данные», «записка», «спецификация» и т.п. в имени)."),
    ('Шифр', 'Ищется в тексте титула, затем в имени файла, затем в именах папок. Хвостовые обозначения документа (.ТЧ, -ПЗ, .СО, .ОД, .С) отбрасываются, поэтому все тома и листы одного комплекта попадают в одну строку. Латинские буквы-двойники в марке заменены кириллицей (CC → СС).'),
    ('Название, система, стадия', 'Из структуры титула: [организация] → объект → стадия (ПРОЕКТНАЯ / РАБОЧАЯ ДОКУМЕНТАЦИЯ, РАБОЧИЙ ПРОЕКТ) → система → шифр. Если титула с такой структурой нет — название из имени папки, система — по марке шифра.'),
    ('Участники', 'Организации — по организационно-правовой форме (ЗАО, ООО, АО, ГКУ…) и словам «Заказчик», «Генпроектировщик», «Генподрядчик» перед ними. Первая организация в шапке титула — проектировщик. Люди — по ролям в титуле и штампе (ГИП, Разраб., Пров., Н. контр., Рук. ПБ…); по каждой роли показаны 1–2 самых частых фамилии по всем файлам комплекта.'),
    ('Год', 'Год с титула, если он согласуется с датой изменения файла (±3 года); иначе — год даты изменения файла-источника (источник указан в столбце «Год: источник»).'),
    ('Адрес (лист «По объектам»)', 'Определяется автоматически, требует проверки. Ищется по очереди: имя папки и итоговое название объекта → другие названия с титулов этой папки → текст титулов. Улица, которая встречается так в 4 и более разных папках (шаблонный титул, ссылка), отбрасывается. Распознаются: город (в т.ч. по сокращениям В.Пышма, Н.Тагил, НТМК, БАЭС → Заречный), улица с домом, «в границах улиц», проспект/переулок/площадь, микрорайон, квартал, посёлок. Если улицы нет — «г. …; объект: …», если нет и города — «объект: …» (название, по которому можно найти адрес).'),
    ('Путь к проекту', 'Общая папка всех найденных файлов комплекта (если они разбросаны — папка объекта). Ссылки открываются при подключённом диске Z:.'),
    ('Требует проверки', 'Перечислено, что взято не с титула. Жёлтым выделены строки, где сам шифр найден только в имени файла или папки — их стоит проверить первыми.'),
    ('Ограничения', 'Из .dwg текст не извлекается. 360 PDF — сканы без текстового слоя (лист «Сканы PDF»), их можно распознать отдельно. Ошибки разбора возможны: шифры заказчика и генпроектировщика (ПСД…, СДП…, АТОМ…) идут отдельными строками.'),
]
for i, (a, b) in enumerate(info, 1):
    sh.cell(i, 1, a).font = Font(bold=True, size=12 if i == 1 else 10, color=NAVY)
    sh.cell(i, 2, b).alignment = Alignment(wrap_text=True, vertical='top')
sh.column_dimensions['A'].width = 24; sh.column_dimensions['B'].width = 120

wb.calculation.fullCalcOnLoad = True
wb.active = 0
wb.save(OUT)
print('saved', OUT, len(R))
