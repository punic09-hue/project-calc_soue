import re, collections

CITIES = [
    ('Екатеринбург', r'Екатеринбург\w*|Екб\b'),
    ('Верхняя Пышма', r'Верхн\w*\s+Пышм\w*|В\.\s?Пышм\w*|(?<![А-Яа-яё])Пышм\w*|Боев\w*\s+слав\w*\s+Урала|Музе\w*\s+(?:военной|автомобильной|авиационной)\s+техники|Уралэлектромед\w*'),
    ('Нижний Тагил', r'Нижн\w*\s+Тагил\w*|Н\.\s?Тагил\w*|(?<![А-Яа-яё])Тагил\w*|НТМК'),
    ('Заречный', r'Заречн\w*|БАЭС|Белоярск\w*\s+АЭС'),
    ('Первоуральск', r'Первоуральск\w*'), ('Берёзовский', r'Бер[её]зовск\w*'), ('Арамиль', r'Арамил\w*'),
    ('Богданович', r'Богданович\w*'), ('Оренбург', r'Оренбург\w*|Орнебург\w*'), ('Москва', r'(?<![А-Яа-яё])Москв[аеуы]\b'),
    ('Каменск-Уральский', r'Каменск\w*'), ('Ревда', r'(?<![А-Яа-яё])Ревд\w*'), ('Полевской', r'Полевско\w*'),
    ('Сысерть', r'Сысерт\w*'), ('Асбест', r'(?<![А-Яа-яё])Асбест\w*'), ('Новоуральск', r'Новоуральск\w*'),
    ('Среднеуральск', r'Среднеуральск\w*'), ('Серов', r'(?<![А-Яа-яё])Серов\w*'), ('Челябинск', r'Челябинск\w*'),
    ('Тюмень', r'Тюмен\w*'), ('Пермь', r'(?<![А-Яа-яё])Перм[ьи]\b'), ('Краснотурьинск', r'Краснотурьинск\w*'),
    ('Кировград', r'Кировград\w*'), ('Качканар', r'Качканар\w*'), ('Ирбит', r'(?<![А-Яа-яё])Ирбит\b'),
    ('Новосибирск', r'Новосибирск\w*'), ('Курган', r'(?<![А-Яа-яё])Курган\w*'), ('Уфа', r'(?<![А-Яа-яё])Уф[аеы]\b'),
    ('Магнитогорск', r'Магнитогорск\w*'), ('Сухой Лог', r'Сух\w*\s+Лог\w*'), ('Алапаевск', r'Алапаевск\w*'),
    ('Реж', r'(?<![А-Яа-яё])Реж\w*\b'), ('Лесной', r'г\.\s?Лесно\w*'), ('Новая Ляля', r'Нов\w*\s+Ляля'),
]
CITY_RX = [(c, re.compile(p)) for c, p in CITIES]
END = r'(?=\s*(?:,|;|\.\s|\(|\)|»|"|\s+[вВ]\s|\s+г\.|\s+на\s|\s+с\s|\s+под\s|\s+для\s|\s+[А-ЯЁ]{3,}|\s+\d+\s*[-–]?\s*(?:эт|очеред|секц)|$))'
STREET_RX = [
    re.compile(r'в\s+границах\s+улиц\s+([А-ЯЁ0-9][^.;()«»"]{3,80}?)' + END),
    re.compile(r'(?:(?<![А-Яа-яё])ул\.?\s|ул\.|улиц[аеыиу]?\.?)\s*([А-ЯЁа-яё0-9][А-Яа-яЁё0-9.\- ]{1,40}?(?:\s*[-–]\s*[А-ЯЁ][А-Яа-яЁё.]+)*)(\s*,?\s*(?:д\.\s*|дом\s*)?\d{1,3}[А-Яа-я]?(?:/\d+)?)?' + END),
    re.compile(r'((?:пр\.|просп(?:ект)?\.?|пер\.|переул\w*|бульвар\w*|б-р|площад\w*|ш\.|шоссе|тракт\w*|наб\.)\s*[А-ЯЁ][А-Яа-яЁё\-]+(?:\s*,?\s*(?:д\.\s*)?\d{1,3}[А-Яа-я]?)?)'),
    re.compile(r'((?:микрорайон\w*|мкр\.?|жил\w*\s+район\w*)\s*[«"]?[А-ЯЁ][А-Яа-яЁё\-]+[»"]?)'),
    re.compile(r'(квартал\w*\s*№?\s*\d+[А-Яа-я]?|(?<![А-Яа-яё])кв\.\s?[А-ЯЁ][А-Яа-яЁё\-]+(?:\s*[-–]\s*[А-ЯЁ][А-Яа-яЁё]+)*)'),
    re.compile(r'((?<![А-Яа-яЁё])[А-ЯЁ][а-яё]+(?:ая|ой|ий|ый)\s+(?:пл\.|площадь|ул\.|улица)(?:\s*,?\s*(?:д\.\s*)?\d{1,3}[А-Яа-я]?)?)'),
    re.compile(r'(?:в\s+)((?:п\.|пос\.|пос[её]лке|с\.)\s?[А-ЯЁ][а-яё]{3,})(?![а-яё])|((?:пос\.|пос[её]лок)\s?[А-ЯЁ][а-яё]{3,})(?![а-яё])'),
]
CUT_WORD = re.compile(r'\s+(?:[А-ЯЁ][а-яё]+(?:ция|ние|ство|тура)|Жил\w*|Здани\w*|Корпус\w*|Проект\w*|Объект\w*)(?![а-яё])')
BAD_STREET = re.compile(r'^(Свердловск|Российск|Главн|Технич|Обычн|Изм|Лист|Москва$)', re.I)


def streets(text):
    out = []
    for i, rx in enumerate(STREET_RX):
        for m in rx.finditer(text):
            if i == 0:
                s = 'в границах улиц ' + m.group(1).strip()
            elif i == 1:
                name = m.group(1).strip(' .-')
                if CUT_WORD.search(name):   # «ул. Студенческая Диспетчеризация лифтов…» -> «Студенческая», номер дома тогда чужой
                    name = name[:CUT_WORD.search(name).start()].strip(' .-'); m2 = None
                else:
                    m2 = m.group(2)
                if BAD_STREET.match(name) or len(name) < 3:
                    continue
                num = (m2 or '').strip(' ,')
                num = re.sub(r'^(?:д\.|дом)\s*', '', num)
                s = 'ул. ' + name[:1].upper() + name[1:] + (', ' + num if num else '')
            else:
                s = (m.group(1) or m.group(m.lastindex)).strip()
                s = re.sub(r'^квартал\w*', 'квартал', s)
                if i == 5 and re.match(r'д\.\s?\d', s):
                    continue
            s = re.sub(r'\s+', ' ', s)
            out.append(s)
    return out


def cities(text):
    return [c for c, rx in CITY_RX if rx.search(text)]


def street_key(s):
    return re.sub(r',.*', '', re.sub(r'^(в границах улиц|ул\.)', '', s.lower().replace('ё', 'е'))).replace(' ', '')[:7]


def text_streets(texts_weighted):
    """улицы, найденные только в текстах титулов (для отсева «кочующих» адресов из шаблонов)"""
    return {street_key(s) for t, w in texts_weighted if w < 4 for s in streets(t)}


def locate(texts_weighted, fallback_name, banned=()):
    """texts_weighted: [(text, weight)]; вес >= 2 — имя папки и названия объекта (приоритет), 1 — тексты титулов."""
    def collect(items, skip=()):
        cc = collections.Counter(); sc = collections.Counter(); first = {}
        for t, w in items:
            for c in dict.fromkeys(cities(t)):
                cc[c] += w
            for s in dict.fromkeys(streets(t)):
                k = street_key(s)
                if k in skip:
                    continue
                sc[k] += w; first.setdefault(k, s)
        return cc, sc, first
    cc, sc, first = collections.Counter(), collections.Counter(), {}
    for lo_w, hi_w in ((4, 99), (2, 3.9), (0, 1.9)):   # папка и итоговое название -> прочие названия -> тексты титулов
        c1, s1, f1 = collect([x for x in texts_weighted if lo_w <= x[1] <= hi_w], banned if hi_w < 4 else ())
        if not cc and c1:
            cc = c1
        if not sc and s1:
            sc, first = s1, f1
    city = cc.most_common(1)[0][0] if cc else ''
    sts = []
    if sc:
        top = sc.most_common(1)[0][1]
        for k, v in sc.most_common(3):
            kx = [re.sub(r'^(в границах улиц|ул\.)', '', x.lower().replace('ё', 'е')).replace(' ', '') for x in sts]
            if v >= max(1, top / 3) and not any(k in x or x in k for x in kx):
                sts.append(first[k])
    parts = (['г. ' + city] if city else []) + sts[:2]
    if sts:
        return ', '.join(parts)
    if city:
        return 'г. ' + city + '; объект: ' + fallback_name[:120]
    return 'объект: ' + fallback_name[:150]
