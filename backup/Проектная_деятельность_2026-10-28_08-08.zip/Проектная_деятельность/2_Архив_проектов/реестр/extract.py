exec(open(__file__.replace('extract.py', 'parse.py')).read())
import os

KIND_SCORE = [('титул', 6), ('обложк', 5), ('общ', 3), ('записк', 3), ('пояснит', 3), ('пз', 2), ('тч', 2), ('состав', 1), ('ведомост', 0), ('спецификац', 0), ('со', 0)]
OWN_ORG = 'Уралсвязьмонтаж'


def kind_score(name):
    n = name.lower()
    return max([s for k, s in KIND_SCORE if k in n] or [0])


def orgs_of(text):
    res = []
    for m in ORG_RX.finditer(text):
        o = norm_org(m.group(0))
        if len(o) < 6:
            continue
        before = text[max(0, m.start() - 45):m.start()]
        role = ''
        for rn, rx in ROLE_ORG:
            if rx.search(before):
                role = rn
        res.append((m.start(), m.end(), o, role))
    return res


def title_parts(text, shifr_pos):
    """Название объекта и система по структуре титула: [организации] Объект СТАДИЯ Система ШИФР"""
    st = STAGE_RX.search(text[:1500])
    stage = ''
    obj = sysname = ''
    mo = re.search(r'Объект\s*:\s*(.+?)\s*(?=Раздел\s*:|Обозначение\s*:|Шифр\s*:|Стадия|РАБОЧ|ПРОЕКТН|$)', text[:1500])
    if mo:
        ms = re.search(r'Раздел\s*:\s*(.+?)\s*(?=Обозначение|Шифр|Том|$)', text[:1500])
        if st:
            stage = next(v for k, v in STAGE_MAP if k in st.group(1).upper())
        return stage, mo.group(1).strip(' ,.')[:300], (ms.group(1).strip(' ,.')[:250] if ms else '')
    if st:
        w = st.group(1).upper()
        stage = next(v for k, v in STAGE_MAP if k in w)
        head = text[:st.start()]
        orgs = orgs_of(head)
        cut = max([e for s, e, o, r in orgs] + [0])
        obj = head[cut:]
        obj = JUNK.sub(' ', obj)
        obj = re.sub(r'[^.]*_{3,}[^.]*', ' ', obj)
        obj = re.sub(r'(ЗАКАЗЧИК|Заказчик|ТЕХНИЧЕСКИЙ|Государственный\s+заказчик)\s*$', '', obj.strip())
        obj = re.sub(r'^(?:\s|[-–:,.]|Объект\s*:?)+', '', obj)
        obj = re.sub(r'\s+', ' ', obj).strip(' ,.-–«»"')
        if shifr_pos is not None and shifr_pos > st.end():
            sysname = text[st.end():shifr_pos]
            sysname = re.sub(r'^(?:\s|[-–:,.])+|(?:Раздел\s*:?\s*$)', '', sysname)
            sysname = re.sub(r'(Обозначение|Шифр)\s*:?\s*$', '', sysname)
            sysname = re.sub(r'\s+', ' ', sysname).strip(' ,.-–:')
    return stage, obj[:300], sysname[:250]


groups = collections.defaultdict(list)
for d in docs:
    s = d['t_sh'] or d['n_sh'] or d['f_sh']
    d['src'] = 'текст' if d['t_sh'] else 'имя файла' if d['n_sh'] else 'папка' if d['f_sh'] else ''
    if not s:
        continue
    d['shifr_full'] = s[0][1]
    d['shifr_pos'] = s[0][0] if d['t_sh'] else None
    d['key'] = strip_doctype(s[0][1])
    d['others'] = [x[1] for x in d['t_sh'][1:4] if strip_doctype(x[1]) != d['key']]
    groups[d['key']].append(d)


def common_dir(paths):
    sp = [p.split('\\')[:-1] for p in paths]
    pre = os.path.commonprefix(sp)
    return '\\'.join(pre)


def folder_year(path):
    y = path.split('\\')[2] if len(path.split('\\')) > 2 else ''
    m = re.match(r'(\d{4})', y)
    return int(m.group(1)) if m else None


records = []
for key, ds in groups.items():
    def score(d):
        bad = bool(re.search(r'ведомост|спецификац', d['r']['Имя'], re.I)) or bool(re.match(r'\s*(Позиция|Ведомость|Лист\s+Наименование|Обозначение\s+Наименование)', d['text']))
        return (bool(d['t_sh']), not bad, bool(STAGE_RX.search(d['text'][:1500])), kind_score(d['r']['Имя']), d['r']['Изменён'])
    ds.sort(key=score, reverse=True)
    best = ds[0]
    text = best['text']
    full = text + ' ' + best['stamp']
    stage, obj, sysname = title_parts(text, best['shifr_pos'])
    for d in ds[1:40]:
        if obj and not re.match(r'(Содержание|Ведомость|Позиция|Лист|Обозначение)', obj):
            break
        if d['t_sh']:
            stage2, obj2, sys2 = title_parts(d['text'], d['t_sh'][0][0])
            if obj2 and not re.match(r'(Содержание|Ведомость|Позиция|Лист|Обозначение)', obj2):
                stage, obj, sysname = stage2 or stage, obj2, sys2 or sysname
    if re.match(r'(Содержание|Ведомость|Позиция|Лист|Обозначение)', obj or ''):
        obj = ''
    obj = re.sub(r'^(?:Государственный\s+)?[Зз]аказчик\s*[-–:]?\s*' + LEGAL + r'.*?»+\s*', '', obj or '').strip()
    mp = re.search(r'Подраздел\s*\d*\.?\s*[«"]?(.+)', sysname or '')
    if mp:
        sysname = mp.group(1).strip(' «»".')
    elif re.match(r'Раздел\s*\d', sysname or '') and sys_from_mark(key):
        sysname = sys_from_mark(key)
    orgs = orgs_of(full[:2500])
    designer = ''; cust = ''; gp = ''; gpodr = ''; other = []
    for s, e, o, r in orgs:
        if r == 'Заказчик' and not cust:
            cust = o
        elif r == 'Генпроектировщик' and not gp:
            gp = o
        elif r == 'Генподрядчик' and not gpodr:
            gpodr = o
        elif not designer and s < 400:
            designer = o
        elif o not in other:
            other.append(o)
    other = [o for o in other if o not in (designer, cust, gp, gpodr)]
    # люди: по лучшему документу, недостающие роли — из остальных документов группы
    votes = collections.defaultdict(collections.Counter)
    for i, d in enumerate(ds[:60]):
        for r, n in people(d['text'] + ' ' + d['stamp']).items():
            votes[r][n] += 3 if i == 0 else 1
    ppl = {r: ', '.join(n for n, _ in c.most_common(2) if _ >= max(1, c.most_common(1)[0][1] // 3)) for r, c in votes.items()}
    fy = folder_year(best['r']['Путь'])
    my = int(best['r']['Изменён'][:4]) if best['r']['Изменён'][:4].isdigit() else None
    is_title = kind_score(best['r']['Имя']) >= 5 or bool(STAGE_RX.search(text[:1500]))
    y = None
    if is_title:
        tail_text = text[best['shifr_pos']:best['shifr_pos'] + 400] if best['shifr_pos'] is not None else text[:1500]
        y, _ = year_of(tail_text, None)
        if y is None:
            y, _ = year_of(text[:1500], None)
    year_src = 'титул'
    if y is not None and my and not (my - 3 <= y <= my + 1):
        year_src = 'дата файла (на титуле %d)' % y
        y = my
    if y is None:
        y, year_src = (my, 'дата файла') if my else (fy, 'папка архива')
    if not sysname:
        sysname = sys_from_mark(key)
    if not obj:
        pf = best['pf'].split('\\')[-1]
        obj = re.sub(r'^[_\s]*\d{3}(?:\s*,\s*\d{3})*[_\s]*', '', pf).replace('_', ' ').strip()
        obj_src = 'по имени папки'
    else:
        obj_src = ''
    order = re.search(r'^_?\s*(\d{3}(?:\s*,\s*\d{3})*)', best['pf'].split('\\')[-1])
    paths = [d['r']['Путь'] for d in ds]
    cdir = common_dir(paths)
    if cdir.count('\\') < 3:
        cdir = best['pf']
    flags = []
    if best['src'] != 'текст':
        flags.append('шифр найден только в ' + best['src'])
    if obj_src:
        flags.append('название ' + obj_src)
    if not ppl:
        flags.append('участники-люди не найдены')
    records.append(dict(
        shifr=key, shifr_full=best['shifr_full'], others=', '.join(dict.fromkeys(best['others'])),
        name=obj, system=sysname, stage=stage, designer=designer, customer=cust, genproj=gp, genpodr=gpodr,
        other_orgs='; '.join(other[:4]), people=ppl, year=y, year_src=year_src,
        order=order.group(1) if order else '', proj_folder=best['pf'], path=cdir, best_file=best['r']['Путь'],
        nfiles=len(ds), flags='; '.join(flags), text=text[:600], addr_text=' | '.join(dict.fromkeys(x['text'][:900] for x in ds[:8] if x['text']))[:4000]))

nos = collections.defaultdict(int)
for d in docs:
    if not d.get('key'):
        nos[d['pf']] += 1
have = {r['proj_folder'] for r in records}
no_shifr_folders = sorted((k, v) for k, v in nos.items() if k not in have)
scans = [d['r']['Путь'] for d in docs if d['r']['Примечание'].startswith('нет текста')]
json.dump(dict(records=records, no_shifr=no_shifr_folders, total=len(docs), scans=scans), open(sys.argv[2], 'w'), ensure_ascii=False)
print(len(records), 'records;', len(no_shifr_folders), 'folders without shifr')
