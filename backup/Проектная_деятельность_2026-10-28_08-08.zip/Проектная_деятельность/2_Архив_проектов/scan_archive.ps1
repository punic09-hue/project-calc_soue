﻿# Опись архива проектов: выбираете папки в окне, всё пишется в один CSV для Excel
# Запуск: двойной клик по scan_archive.bat
param(
    [string]$Server = '\\192.168.100.8\project',
    [string]$OutDir = [Environment]::GetFolderPath('Desktop')
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Windows.Forms

$columns = @(
    @('Источник',      'папка, которую вы выбрали в окне'),
    @('Тип',           'Папка или Файл'),
    @('Уровень',       'глубина вложенности от выбранной папки (1 = прямо в ней)'),
    @('Путь',          'полный путь к папке или файлу'),
    @('Папка',         'папка, в которой лежит объект'),
    @('Имя',           'имя папки или файла'),
    @('Расширение',    '.pdf, .docx, .dwg и т.д. (у папок пусто)'),
    @('Размер_КБ',     'размер файла в килобайтах (у папок пусто)'),
    @('Изменён',       'дата и время последнего изменения'),
    @('Создан',        'дата и время создания')
)
Write-Host 'Скрипт запишет в CSV такие столбцы:' -ForegroundColor Cyan
$i = 0; foreach ($c in $columns) { $i++; Write-Host ("  {0,2}. {1,-12} {2}" -f $i, $c[0], $c[1]) }
Write-Host ''

# Путь к архиву: спрашиваем при запуске, по умолчанию сетевой диск
Add-Type -AssemblyName Microsoft.VisualBasic
$Server = [Microsoft.VisualBasic.Interaction]::InputBox(
    "Введите путь к архиву (сетевой диск или папка на компьютере).`n`nДалее откроется окно выбора папок внутри него.",
    'Опись архива: путь к архиву', $Server).Trim().TrimEnd('\')
if (-not $Server) { Write-Host 'Путь не указан, выход.' -ForegroundColor Yellow; pause; exit }

# Доступ к сетевому диску (логин и пароль спросит Windows, если нужно)
if ($Server.StartsWith('\\') -and -not (Test-Path -LiteralPath $Server)) {
    Write-Host "Нет доступа к $Server. Введите логин и пароль от сетевого диска." -ForegroundColor Yellow
    cmd /c "net use `"$Server`""
}
if (-not (Test-Path -LiteralPath $Server)) {
    Write-Host "Путь $Server недоступен. Окно выбора откроется с Рабочего стола." -ForegroundColor Yellow
}

# Куда сохранить опись
$stamp = Get-Date -Format 'yyyy-MM-dd_HH-mm'
$save = New-Object System.Windows.Forms.SaveFileDialog
$save.Title = 'Куда сохранить опись'
$save.Filter = 'CSV для Excel (*.csv)|*.csv'
$save.InitialDirectory = $OutDir
$save.FileName = "archive_inventory_$stamp.csv"
if ($save.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Write-Host 'Отменено.' -ForegroundColor Yellow; pause; exit }
$csvPath = $save.FileName
$errPath = [IO.Path]::ChangeExtension($csvPath, $null).TrimEnd('.') + '_errors.txt'

$enc = New-Object System.Text.UTF8Encoding($true)   # UTF-8 с BOM: Excel сразу видит кириллицу
$w   = New-Object System.IO.StreamWriter($csvPath, $false, $enc)
$err = New-Object System.IO.StreamWriter($errPath, $false, $enc)
$w.WriteLine((($columns | ForEach-Object { $_[0] }) -join ';'))

function Q([object]$v) { '"' + ([string]$v).Replace('"', '""') + '"' }
function Clean([string]$p) { $p.Replace('\\?\UNC\', '\\').Replace('\\?\', '') }
function LongPath([string]$p) {   # пути длиннее 260 символов
    $lp = if ($p.StartsWith('\\')) { '\\?\UNC\' + $p.TrimStart('\') } else { '\\?\' + $p }
    try { [void][System.IO.Directory]::GetDirectories($lp); $lp } catch { $p }
}

$totalFiles = 0; $totalDirs = 0; $totalBytes = 0
$done = @()
$lastPath = if (Test-Path -LiteralPath $Server) { $Server } else { '' }
$sw = [Diagnostics.Stopwatch]::StartNew()

while ($true) {
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'Выберите папку с проектами для описи'
    $dlg.ShowNewFolderButton = $false
    if ($lastPath) { $dlg.SelectedPath = $lastPath }
    if ($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { break }
    $src = $dlg.SelectedPath.TrimEnd('\')
    $lastPath = $src

    if ($done | Where-Object { $src -eq $_ -or $src.StartsWith($_ + '\') }) {
        Write-Host "Папка $src уже вошла в опись, пропускаю." -ForegroundColor Yellow
    } else {
        Write-Host "Сканирую: $src" -ForegroundColor Cyan
        $walkRoot = LongPath $src
        $rootLen  = $src.Length
        $stack = New-Object System.Collections.Stack
        $stack.Push((New-Object System.IO.DirectoryInfo($walkRoot)))
        $nFiles = 0; $nDirs = 0
        while ($stack.Count -gt 0) {
            $dir = $stack.Pop()
            try {
                foreach ($e in $dir.EnumerateFileSystemInfos()) {
                    $full  = Clean $e.FullName
                    $level = ($full.Substring($rootLen).TrimStart('\').Split('\')).Count
                    $mod   = $e.LastWriteTime.ToString('yyyy-MM-dd HH:mm')
                    $cre   = $e.CreationTime.ToString('yyyy-MM-dd HH:mm')
                    if (($e.Attributes -band [IO.FileAttributes]::Directory) -ne 0) {
                        $nDirs++; $stack.Push($e)
                        $row = @($src, 'Папка', $level, $full, (Clean $dir.FullName), $e.Name, '', '', $mod, $cre)
                    } else {
                        $nFiles++; $totalBytes += $e.Length
                        $row = @($src, 'Файл', $level, $full, (Clean $dir.FullName), $e.Name, $e.Extension.ToLower(),
                                 ([math]::Round($e.Length / 1KB, 1)).ToString([Globalization.CultureInfo]::GetCultureInfo('ru-RU')), $mod, $cre)
                    }
                    $w.WriteLine((($row | ForEach-Object { Q $_ }) -join ';'))
                    if ((($nFiles + $nDirs) % 5000) -eq 0) { Write-Host ("  папок: {0}, файлов: {1}" -f $nDirs, $nFiles) }
                }
            } catch {
                $err.WriteLine((Clean $dir.FullName) + "`t" + $_.Exception.Message)
            }
        }
        $w.Flush()
        $done += $src; $totalFiles += $nFiles; $totalDirs += $nDirs
        Write-Host ("  Готово: папок {0}, файлов {1}" -f $nDirs, $nFiles) -ForegroundColor Green
    }

    $more = [System.Windows.Forms.MessageBox]::Show("Папка добавлена в опись.`n`nВыбрать ещё одну папку?", 'Опись архива',
            [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
    if ($more -ne [System.Windows.Forms.DialogResult]::Yes) { break }
}
$w.Close(); $err.Close()

Write-Host ''
if ($done.Count -eq 0) {
    Remove-Item $csvPath, $errPath
    Write-Host 'Ни одна папка не выбрана, файл не создан.' -ForegroundColor Yellow
} else {
    Write-Host ("Готово за {0:hh\:mm\:ss}. Папок: {1}, файлов: {2}, объём {3:N1} ГБ" -f $sw.Elapsed, $totalDirs, $totalFiles, ($totalBytes / 1GB)) -ForegroundColor Green
    Write-Host 'Просканированы:'; $done | ForEach-Object { Write-Host "  $_" }
    Write-Host "Опись: $csvPath"
    if ((Get-Item $errPath).Length -gt 3) { Write-Host "Папки без доступа: $errPath" -ForegroundColor Yellow } else { Remove-Item $errPath }
}
pause
