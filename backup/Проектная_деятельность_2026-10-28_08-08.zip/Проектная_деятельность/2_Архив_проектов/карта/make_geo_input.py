"""Готовит geo_input.csv для geocode.ps1: по строке листа «По объектам» — варианты запросов к геокодеру (от точного к грубому)."""
import sys, re, csv
from openpyxl import load_workbook

REGION = {'Екатеринбург': '', 'Москва': '', 'Челябинск': 'Челябинская область', 'Оренбург': 'Оренбургская область',
          'Тюмень': 'Тюменская область', 'Пермь': 'Пермский край', 'Новосибирск': 'Новосибирская область',
          'Курган': 'Курганская область', 'Уфа': 'Башкортостан', 'Магнитогорск': 'Челябинская область'}
SPECIAL = [  # известные объекты: название -> запрос
    (r'БАЭС|Белоярск\w*\s+АЭС', 'Белоярская АЭС', ''),
    (r'Боев\w*\s+слав\w*\s+Урала|Музе\w*\s+(?:военной|автомобильной|авиационной)\s+техники', 'Боевая слава Урала, Верхняя Пышма', 'Пышма'),
    (r'Боев\w*\s+слав\w*\s+Урала|Музе\w*\s+(?:военной|автомобильной|авиационной)\s+техники', 'Музейный комплекс УГМК, Верхняя Пышма', 'Пышма'),
    (r'НТМК', 'Нижнетагильский металлургический комбинат', 'Тагил'),
]
KIND = [(r'^ул\.\s*', 'улица '), (r'^пр\.\s*', 'проспект '), (r'^пер\.\s*', 'переулок '), (r'^бульвару?\s*', 'бульвар '),
        (r'^микрорайон\w*\s*', 'микрорайон '), (r'^мкр\.?\s*', 'микрорайон '), (r'^(?:п\.|пос\.|пос[её]лке?)\s*', 'посёлок ')]


def city_full(c):
    r = REGION.get(c, 'Свердловская область')
    return c + (', ' + r if r else '')


def nominative(w):
    # «по ул. Московской» -> «Московская»; фамилии (Малышева, Репина) не трогаем
    return re.sub(r'(ск|цк|н|в|ж|ч|т|р|л)ой$', r'\1ая', w)


def street_queries(part, city):
    part = re.sub(r'\s+', ' ', part).strip(' ,.«»"')
    m = re.match(r'в границах улиц\s+(.+)', part)
    if m:
        part = 'ул. ' + m.group(1)
    num = ''
    mn = re.search(r'(?:,\s*|\s+)(\d{1,3}[А-Яа-я]?(?:/\d+)?)$', part)
    if mn:
        num = mn.group(1); part = part[:mn.start()]
    kind = None
    for rx, k in KIND:
        if re.match(rx, part):
            kind = k; part = re.sub(rx, '', part); break
    if kind is None:
        return []
    name = re.split(r'\s*[-–]\s*', part)[0].strip()          # перекрёсток «А-Б» -> первая улица
    name = re.sub(r'^([А-ЯЁ])\.\s?', r'\1. ', name)            # Р.Люксембург -> Р. Люксембург
    name = re.sub(r'\s+(?:пос|ул|пер|Выноска|Энергия|ДС)\b.*$', '', name).strip()
    if len(name) < 3:
        return []
    variants = [name]
    w = name.split(' ')
    nom = ' '.join([nominative(w[0])] + w[1:])
    if nom != name:
        variants.insert(0, nom)
    out = []
    loc = city_full(city)
    for v in variants:
        if num and kind in ('улица ', 'переулок ', 'проспект ', 'бульвар '):
            out.append(('дом', '%s, %s%s, %s' % (loc, kind, v, num)))
    for v in variants:
        out.append(('улица' if kind != 'посёлок ' else 'посёлок', '%s, %s%s' % (loc, kind, v)))
    return out


def main(src, dst):
    ws = load_workbook(src)['По объектам']
    rows = []
    for r in ws.iter_rows(min_row=4, values_only=True):
        no, year, name, shifrs, systems, orgs, ppl, path, addr = r[:9]
        addr = addr or ''
        qs = []
        for rx, q, chk in SPECIAL:
            if re.search(rx, (name or '') + ' ' + (path or '').split('\\')[-1]):
                qs.append(('объект', q, chk))
        m = re.match(r'г\.\s*([^,;]+)', addr)
        city = m.group(1).strip() if m else ''
        if addr.startswith('объект:'):
            pass
        elif not city:
            city = 'Екатеринбург'          # улица без города: архив бюро в основном по Екатеринбургу
            if not qs:
                pass
        body = re.sub(r'^г\.\s*[^,;]+[,;]?\s*', '', addr) if m else ('' if addr.startswith('объект:') else addr)
        if body and not body.startswith('объект:'):
            for part in re.split(r',\s*(?=(?:ул\.|пр\.|пер\.|бульвар|микрорайон|мкр|п\.|пос|в границах))', body)[:2]:
                qs += [(lvl, q, city[:6]) for lvl, q in street_queries(part, city)]
        if city and not addr.startswith('объект:'):
            qs.append(('город', city_full(city), city[:6]))
        if not qs:
            continue
        guessed = 'город не указан, принят Екатеринбург' if (not m and not addr.startswith('объект:')) else ''
        seen = []
        for q in qs:
            if q not in seen:
                seen.append(q)
        rows.append([no, year, name, addr, (shifrs or '').replace('\n', ', '), (systems or '').replace('\n', '; '), path, guessed]
                    + ['|'.join(q) for q in seen[:6]] + [''] * (6 - len(seen[:6])))
    with open(dst, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f, delimiter=';')
        w.writerow(['№', 'Год', 'Название', 'Адрес', 'Шифры', 'Системы', 'Путь', 'Примечание'] + ['Запрос%d' % i for i in range(1, 7)])
        w.writerows(rows)
    print(len(rows), 'rows')


main(sys.argv[1], sys.argv[2])
