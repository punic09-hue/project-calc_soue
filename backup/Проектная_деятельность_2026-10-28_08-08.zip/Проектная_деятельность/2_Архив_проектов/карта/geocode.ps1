﻿<#
  Объекты архива на Яндекс Картах.
  Берёт geo_input.csv (лежит рядом со скриптом), для каждого объекта по очереди пробует запросы
  к открытому геокодеру OpenStreetMap (nominatim.openstreetmap.org) и сохраняет на Рабочий стол:
    Объекты_на_карте_<дата>.kml  — для импорта в Конструктор Яндекс Карт;
    Объекты_на_карте_<дата>.csv  — таблица с координатами и точностью (для проверки в Excel).
  Скрипт НЕ обращается к архиву проектов и ничего в нём не меняет: он читает только geo_input.csv,
  в интернет отправляются только адреса из этого файла.
  Геокодер разрешает 1 запрос в секунду, поэтому работа занимает 5–15 минут.
  Найденное копится в geo_cache.csv рядом со скриптом: при повторном запуске уже найденное не запрашивается.
#>
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$InFile = Join-Path $Here 'geo_input.csv'
$CacheFile = Join-Path $Here 'geo_cache.csv'
$OutDir = [Environment]::GetFolderPath('Desktop')
$Stamp = Get-Date -Format 'yyyy-MM-dd_HH-mm'
$Inv = [Globalization.CultureInfo]::InvariantCulture

if (-not (Test-Path -LiteralPath $InFile)) { Write-Host "Не найден $InFile" -ForegroundColor Red; Read-Host 'Enter — выход'; exit 1 }
$rows = Import-Csv -LiteralPath $InFile -Delimiter ';' -Encoding UTF8

# кэш: запрос -> lat;lon;display_name ('' — не найдено)
$cache = @{}
if (Test-Path -LiteralPath $CacheFile) {
    foreach ($c in (Import-Csv -LiteralPath $CacheFile -Delimiter ';' -Encoding UTF8)) { $cache[$c.Query] = $c }
}

$web = New-Object System.Net.WebClient
$web.Encoding = [Text.Encoding]::UTF8
$web.Proxy = [System.Net.WebRequest]::GetSystemWebProxy()
$web.Proxy.Credentials = [System.Net.CredentialCache]::DefaultCredentials

function Get-Geocode([string]$q) {
    if ($cache.ContainsKey($q)) { return $cache[$q] }
    $url = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=ru&accept-language=ru&q=' + [uri]::EscapeDataString($q)
    $web.Headers['User-Agent'] = 'project-archive-map/1.0 (Uralsvyazmontazh design bureau)'
    $raw = $null
    for ($try = 1; $try -le 3; $try++) {
        try { $raw = $web.DownloadString($url); break }
        catch { Write-Host "  сеть: $($_.Exception.Message) — повтор через 5 с" -ForegroundColor Yellow; Start-Sleep -Seconds 5 }
    }
    Start-Sleep -Milliseconds 1100
    if ($raw -eq $null) { return $null }   # сеть не ответила — в кэш не пишем
    $res = @($raw | ConvertFrom-Json)
    $item = [pscustomobject]@{ Query = $q; Lat = ''; Lon = ''; Found = '' }
    if ($res.Count -gt 0 -and $res[0].lat) { $item.Lat = $res[0].lat; $item.Lon = $res[0].lon; $item.Found = $res[0].display_name }
    $cache[$q] = $item
    $item | Export-Csv -LiteralPath $CacheFile -Delimiter ';' -Encoding UTF8 -NoTypeInformation -Append
    return $item
}

function Esc([string]$s) { [Security.SecurityElement]::Escape($s) }

$out = New-Object System.Collections.ArrayList
$i = 0
foreach ($r in $rows) {
    $i++
    Write-Progress -Activity 'Поиск координат' -Status "$i из $($rows.Count): $($r.'Название')" -PercentComplete ($i * 100 / $rows.Count)
    $hit = $null; $level = ''
    foreach ($k in 1..6) {
        $q = $r."Запрос$k"
        if (-not $q) { continue }
        $p = $q.Split('|')
        $g = Get-Geocode $p[1]
        if ($g -eq $null -or -not $g.Lat) { continue }
        if ($p.Count -gt 2 -and $p[2] -and ($g.Found -notlike "*$($p[2])*")) { continue }   # нашлась улица в другом городе
        $hit = $g; $level = $p[0]; break
    }
    $out.Add([pscustomobject]@{
        'N' = $r.'№'; 'Год' = $r.'Год'; 'Название' = $r.'Название'; 'Адрес_в_реестре' = $r.'Адрес'
        'Точность' = $(if ($hit) { $level } else { 'не найдено' })
        'Широта' = $(if ($hit) { $hit.Lat } else { '' }); 'Долгота' = $(if ($hit) { $hit.Lon } else { '' })
        'Найдено_геокодером' = $(if ($hit) { $hit.Found } else { '' })
        'Шифры' = $r.'Шифры'; 'Системы' = $r.'Системы'; 'Путь' = $r.'Путь'; 'Примечание' = $r.'Примечание'
    }) | Out-Null
}
Write-Progress -Activity 'Поиск координат' -Completed

# точки «по городу» или «по объекту» с одинаковыми координатами разносим по маленькой спирали, чтобы метки не слипались
$groups = @{}
foreach ($o in $out) {
    if (-not $o.'Широта') { continue }
    $key = "$($o.'Широта');$($o.'Долгота')"
    $n = [int]$groups[$key]; $groups[$key] = $n + 1
    $lat = [double]::Parse($o.'Широта', $Inv); $lon = [double]::Parse($o.'Долгота', $Inv)
    if ($n -gt 0) {
        $a = $n * 2.39996; $rad = 0.0012 * [Math]::Sqrt($n)
        $lat += $rad * [Math]::Sin($a); $lon += $rad * [Math]::Cos($a) * 1.9
    }
    $o | Add-Member -NotePropertyName LatF -NotePropertyValue $lat
    $o | Add-Member -NotePropertyName LonF -NotePropertyValue $lon
}

# KML для Яндекс Карт (цвет метки по точности)
$color = @{ 'дом' = 'ff3c14dc'; 'улица' = 'ff0080ff'; 'посёлок' = 'ff0080ff'; 'объект' = 'ff00a000'; 'город' = 'ff808080' }
$sb = New-Object Text.StringBuilder
[void]$sb.AppendLine('<?xml version="1.0" encoding="UTF-8"?>')
[void]$sb.AppendLine('<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>Объекты архива проектов</name>')
foreach ($k in $color.Keys) {
    [void]$sb.AppendLine("<Style id=`"s$($color[$k])`"><IconStyle><color>$($color[$k])</color></IconStyle></Style>")
}
$placed = 0
foreach ($o in $out) {
    if (-not $o.'Широта') { continue }
    $placed++
    $title = "$($o.'Год') · $($o.'Название')"
    if ($title.Length -gt 120) { $title = $title.Substring(0, 117) + '...' }
    $desc = "Год: $($o.'Год')`nАдрес: $($o.'Адрес_в_реестре')`nТочность метки: $($o.'Точность')`nШифры: $($o.'Шифры')`nСистемы: $($o.'Системы')`nПапка: $($o.'Путь')"
    if ($o.'Примечание') { $desc += "`n$($o.'Примечание')" }
    $c = $color[$o.'Точность']
    [void]$sb.AppendLine("<Placemark><name>$(Esc $title)</name><description>$(Esc $desc)</description><styleUrl>#s$c</styleUrl><Point><coordinates>$($o.LonF.ToString($Inv)),$($o.LatF.ToString($Inv)),0</coordinates></Point></Placemark>")
}
[void]$sb.AppendLine('</Document></kml>')
$kml = Join-Path $OutDir "Объекты_на_карте_$Stamp.kml"
[IO.File]::WriteAllText($kml, $sb.ToString(), (New-Object Text.UTF8Encoding($false)))

$csv = Join-Path $OutDir "Объекты_на_карте_$Stamp.csv"
$out | Select-Object N, 'Год', 'Название', 'Адрес_в_реестре', 'Точность', 'Широта', 'Долгота', 'Найдено_геокодером', 'Шифры', 'Системы', 'Путь', 'Примечание' |
    Export-Csv -LiteralPath $csv -Delimiter ';' -Encoding UTF8 -NoTypeInformation

$st = $out | Group-Object 'Точность' | ForEach-Object { "$($_.Name): $($_.Count)" }
Write-Host ''
Write-Host "Готово. На карту попало $placed из $($out.Count) объектов ($($st -join ', '))." -ForegroundColor Green
Write-Host "Файл для Яндекс Карт: $kml"
Write-Host "Таблица для проверки: $csv"
Read-Host 'Enter — выход'
