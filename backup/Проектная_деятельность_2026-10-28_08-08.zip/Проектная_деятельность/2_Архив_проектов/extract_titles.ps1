﻿# Выборка титулов из архива проектов.
# Находит файлы-кандидаты (pdf, dwg, doc, docx с «обложка», «титул», «общие данные», «записка», «спецификация» и т.п. в имени),
# вынимает текст первых страниц и штампа и пишет компактный CSV. Его (в zip) загружаете в чат, из него собирается база xlsx.
# Архив только читается: ничего не удаляется, не переименовывается и не сохраняется.
# Запуск: двойной клик по extract_titles.bat, затем вставить путь (правый клик или Ctrl+V) и нажать Enter.
# Можно и сразу из командной строки:  extract_titles.bat "D:\archive_inventory_2026-10-21.csv"
#                                  или extract_titles.bat "\\192.168.100.8\project\2019"
param([string]$Source = '', [string]$OutDir = [Environment]::GetFolderPath('Desktop'))

$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.IO.Compression.FileSystem

# ---------- Настройки отбора ----------
$Exts = @('.pdf', '.dwg', '.doc', '.docx')
# Слова в имени файла (регистр не важен). Короткие марки (ТЛ, ОД, ПЗ, СО) ищутся как отдельное слово, например «123-ПЗ.pdf».
$NameRx = '(?i)(обложк|титул|тит\.\s*л|общ\w*[\s_.-]*дан|записк|пояснит|спецификац|ведомост|состав[\s_.-]*проект|(?<![а-яёa-z])(тл|од|пз|со|тч)(?![а-яёa-z]))'
# Похоже на шифр проекта: цифры с разделителями и буквенная марка, например 123-2021-АПС, 01.02-19-СОУЭ, П-15/20-ПС
$ShifrRx = '(?<![\w])(?:[А-ЯЁA-Z]{1,4}[-.]?)?\d{1,6}(?:[-./_]\d{1,6}){0,4}(?:[-._][А-ЯЁA-Z][А-ЯЁA-Zа-яё0-9.]{0,10}){1,4}(?![\w])'
$BodyMax  = 2500   # символов текста с первых страниц
$StampMax = 1000   # символов из колонтитулов (штамп)
$MaxPdfMB = 300    # PDF больше этого размера не копируются для чтения

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
# pdftotext.exe: рядом со скриптом, в его подпапке bin64/bin32 или в PATH; иначе спросить путь
$pdftotext = $null
foreach ($p in @((Join-Path $here 'pdftotext.exe'), (Join-Path $here 'bin64\pdftotext.exe'), (Join-Path $here 'bin32\pdftotext.exe'))) {
    if (Test-Path -LiteralPath $p) { $pdftotext = $p; break }
}
if (-not $pdftotext) {
    $cmd = Get-Command pdftotext.exe -ErrorAction SilentlyContinue
    if ($cmd) { $pdftotext = $cmd.Source }
}
while (-not $pdftotext) {
    Write-Host 'Не найден pdftotext.exe (нужен для чтения PDF, входит в бесплатные «Xpdf command line tools» с xpdfreader.com).' -ForegroundColor Yellow
    $p = (Read-Host 'Вставьте путь к pdftotext.exe или к папке с ним (Enter — продолжить без чтения PDF)').Trim().Trim('"').Trim("'").Trim()
    if (-not $p) {
        Write-Host 'Продолжаю без чтения PDF: из них попадут только имена и пути.' -ForegroundColor Yellow; Write-Host ''
        break
    }
    foreach ($q in @($p, (Join-Path $p 'pdftotext.exe'), (Join-Path $p 'bin64\pdftotext.exe'), (Join-Path $p 'bin32\pdftotext.exe'))) {
        if ((Test-Path -LiteralPath $q -PathType Leaf) -and $q -like '*pdftotext.exe') { $pdftotext = $q; break }
    }
    if (-not $pdftotext) { Write-Host "Не нашёл pdftotext.exe по пути: $p" -ForegroundColor Red }
}
if ($pdftotext) { Write-Host "PDF читаю через: $pdftotext" -ForegroundColor Green; Write-Host '' }

# ---------- Откуда брать список файлов ----------
function Unquote([string]$s) { $s.Trim().Trim('"').Trim("'").Trim().TrimEnd('\') }
if (-not $Source) {
    Write-Host 'Вставьте путь и нажмите Enter (вставка: правый клик мыши или Ctrl+V):' -ForegroundColor Cyan
    Write-Host '  - к описи archive_inventory_*.csv (быстро, рекомендуется), или'
    Write-Host '  - к папке архива, например \\192.168.100.8\project (будет заново обходить все папки, это долго)'
    $Source = Read-Host 'Путь'
}
$Source = Unquote $Source
if (-not $Source) { Write-Host 'Путь не указан, выход.' -ForegroundColor Yellow; pause; exit }
if ($Source.StartsWith('\\') -and -not (Test-Path -LiteralPath $Source)) {
    $share = ($Source.TrimStart('\').Split('\') | Select-Object -First 2) -join '\'
    Write-Host "Нет доступа к \\$share. Введите логин и пароль от сетевого диска." -ForegroundColor Yellow
    cmd /c "net use `"\\$share`""
}
if (-not (Test-Path -LiteralPath $Source)) { Write-Host "Путь не найден: $Source" -ForegroundColor Red; pause; exit }

$candidates = New-Object System.Collections.Generic.List[object]
$sw0 = [Diagnostics.Stopwatch]::StartNew()
if ((Get-Item -LiteralPath $Source).PSIsContainer) {
    Write-Host "Обхожу папку: $Source (на сетевом диске это может занять долго, счётчик ниже)" -ForegroundColor Cyan
    $k = 0
    Get-ChildItem -LiteralPath $Source -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
        $k++
        if (($k % 2000) -eq 0) { Write-Host ("  просмотрено файлов: {0}, кандидатов: {1}, {2:hh\:mm\:ss}" -f $k, $candidates.Count, $sw0.Elapsed) }
        if ($Exts -contains $_.Extension.ToLower() -and $_.Name -match $NameRx -and -not $_.Name.StartsWith('~$')) {
            $candidates.Add([pscustomobject]@{ Путь = $_.FullName; Папка = $_.DirectoryName; Имя = $_.Name; Расширение = $_.Extension.ToLower();
                                               Размер_КБ = [math]::Round($_.Length / 1KB, 1); Изменён = $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm') })
        }
    }
} else {
    Write-Host "Читаю опись: $Source" -ForegroundColor Cyan
    $k = 0
    Import-Csv -LiteralPath $Source -Delimiter ';' -Encoding UTF8 | ForEach-Object {
        $k++
        if (($k % 100000) -eq 0) { Write-Host ("  прочитано строк: {0}, кандидатов: {1}" -f $k, $candidates.Count) }
        if ($_.'Тип' -eq 'Файл' -and $Exts -contains $_.'Расширение' -and $_.'Имя' -match $NameRx -and -not $_.'Имя'.StartsWith('~$')) {
            $candidates.Add([pscustomobject]@{ Путь = $_.'Путь'; Папка = $_.'Папка'; Имя = $_.'Имя'; Расширение = $_.'Расширение';
                                               Размер_КБ = $_.'Размер_КБ'; Изменён = $_.'Изменён' })
        }
    }
    if ($k -eq 0) { Write-Host 'Опись пустая или не того формата (нужен CSV от scan_archive, разделитель «;»).' -ForegroundColor Red; pause; exit }
}

$n = $candidates.Count
$byExt = $candidates | Group-Object Расширение | ForEach-Object { "$($_.Name): $($_.Count)" }
Write-Host ("Найдено кандидатов: {0} ({1})" -f $n, ($byExt -join ', ')) -ForegroundColor Green
if ($n -eq 0) { pause; exit }
$ans = Read-Host 'Извлечь из них текст титулов? (Д/Н, Enter = Д)'
if ($ans -and $ans.Trim().ToUpper() -notin @('Д', 'Y', 'ДА', 'YES', 'L')) { exit }

# ---------- Куда сохранить: на Рабочий стол ----------
$stamp = Get-Date -Format 'yyyy-MM-dd_HH-mm'
if (-not (Test-Path -LiteralPath $OutDir)) { $OutDir = $env:USERPROFILE }
$csvPath = Join-Path $OutDir "titles_extract_$stamp.csv"

# Прошлая выборка: уже прочитанные файлы берутся из неё, читаются только новые и с ошибками
$prev = @{}
$prevPath = Unquote (Read-Host 'Путь к прошлой выборке titles_extract_*.csv, чтобы не читать заново (Enter — без неё)')
if ($prevPath -and (Test-Path -LiteralPath $prevPath)) {
    Import-Csv -LiteralPath $prevPath -Delimiter ';' -Encoding UTF8 | ForEach-Object {
        if ($_.'Текст_начало' -and $_.'Примечание' -notlike 'ошибка*') { $prev[$_.'Путь'] = @($_.'Текст_начало', $_.'Текст_штамп') }
    }
    Write-Host ("Из прошлой выборки взято готовых файлов: {0}" -f $prev.Count) -ForegroundColor Green
}
Write-Host "Результат будет сохранён в: $csvPath" -ForegroundColor Cyan

# ---------- Извлечение текста ----------
function Clean([string]$s, [int]$max) {
    if (-not $s) { return '' }
    $s = ($s -replace '[\x00-\x1F\x07]+', ' ' -replace '\s+', ' ').Trim()
    if ($s.Length -gt $max) { $s = $s.Substring(0, $max) }
    $s
}
function XmlText([string]$x) {
    $x = $x -replace '</w:p>', "`n" -replace '<w:tab/>', ' ' -replace '<[^>]+>', ''
    [System.Net.WebUtility]::HtmlDecode($x)
}
function Get-DocxText([string]$path) {
    $z = [System.IO.Compression.ZipFile]::OpenRead((Get-LongPath $path))
    try {
        $body = ''; $st = New-Object System.Text.StringBuilder
        foreach ($e in $z.Entries) {
            if ($e.FullName -notmatch '^word/(document|header\d*|footer\d*)\.xml$') { continue }
            $r = New-Object System.IO.StreamReader($e.Open(), [System.Text.Encoding]::UTF8)
            $x = $r.ReadToEnd(); $r.Close()
            if ($e.FullName -eq 'word/document.xml') {
                if ($x.Length -gt 600000) { $x = $x.Substring(0, 600000) }
                $body = XmlText $x
            } else { [void]$st.Append((XmlText $x)).Append(' ') }
        }
        @($body, $st.ToString())
    } finally { $z.Dispose() }
}
# .doc читается напрямую, без Word (никаких окон): из двоичного файла вынимаются куски текста.
# В .doc текст хранится в UTF-16 (кириллица) или в однобайтовой кодировке, пробуем обе.
$cp1251 = [System.Text.Encoding]::GetEncoding(1251)
$RunRx = '[0-9A-Za-zА-Яа-яЁё№«»"''()\[\]/\\.,:;!?+=%&*_ \t–—-]{4,}'
function Get-Runs([string]$s) {
    $sb = New-Object System.Text.StringBuilder
    foreach ($m in [regex]::Matches($s, $RunRx)) {
        $v = $m.Value.Trim()
        if ($v.Length -lt 4 -or $v -notmatch '[А-Яа-яЁё]{2}') { continue }
        $chars = $v.ToCharArray()
        $top = ($chars | Group-Object | Sort-Object Count -Descending | Select-Object -First 1).Count
        if (($chars | Select-Object -Unique).Count -lt 4 -or $top -gt 0.4 * $chars.Count) { continue }   # двоичный мусор вида «яяяя»
        [void]$sb.Append($v).Append(' ')
        if ($sb.Length -gt 8000) { break }
    }
    $sb.ToString()
}
function Get-DocText([string]$path) {
    $fs = [System.IO.File]::Open((Get-LongPath $path), [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
    try {
        $len = [int][math]::Min($fs.Length, 2MB)
        $buf = New-Object byte[] $len
        $read = $fs.Read($buf, 0, $len)
    } finally { $fs.Close() }
    $u = Get-Runs ([System.Text.Encoding]::Unicode.GetString($buf, 0, $read - ($read % 2)))
    if ($u.Length -lt 100) {
        $a = Get-Runs ($cp1251.GetString($buf, 0, $read))
        if ($a.Length -gt $u.Length) { $u = $a }
    }
    @($u, '')
}
function Get-PdfText([string]$path, [double]$sizeKB) {
    if (-not $pdftotext) { return @('', '') }
    if ($sizeKB -gt $MaxPdfMB * 1024) { throw "PDF больше $MaxPdfMB МБ, пропущен" }
    # Копия во временную папку с латинским именем: pdftotext не любит кириллицу и длинные сетевые пути
    $tmpPdf = Join-Path $env:TEMP ('titles_' + [guid]::NewGuid().ToString('N') + '.pdf')
    $tmpTxt = [System.IO.Path]::ChangeExtension($tmpPdf, '.txt')
    try {
        [System.IO.File]::Copy((Get-LongPath $path), $tmpPdf, $true)
        & $pdftotext -f 1 -l 2 -enc UTF-8 -q $tmpPdf $tmpTxt 2>$null
        $t = if (Test-Path -LiteralPath $tmpTxt) { [System.IO.File]::ReadAllText($tmpTxt, [System.Text.Encoding]::UTF8) } else { '' }
        @($t, '')
    } finally {
        Remove-Item -LiteralPath $tmpPdf, $tmpTxt -ErrorAction SilentlyContinue   # только свои временные копии
    }
}
function Get-LongPath([string]$p) {   # пути длиннее 248 символов
    if ($p.Length -lt 248 -or $p.StartsWith('\\?\')) { return $p }
    if ($p.StartsWith('\\')) { '\\?\UNC\' + $p.TrimStart('\') } else { '\\?\' + $p }
}
function Q([object]$v) { '"' + ([string]$v).Replace('"', '""') + '"' }

$enc = New-Object System.Text.UTF8Encoding($true)
$w = New-Object System.IO.StreamWriter($csvPath, $false, $enc)
$w.WriteLine('№;Шифр_по_имени;Имя;Расширение;Размер_КБ;Изменён;Папка;Путь;Текст_начало;Текст_штамп;Примечание')
$seen = @{}   # одинаковые копии (имя + размер) читаются один раз
$sw = [Diagnostics.Stopwatch]::StartNew()
$i = 0; $nText = 0; $nEmpty = 0; $nErr = 0
foreach ($c in $candidates) {
    $i++
    if (($i % 10) -eq 0) {
        $left = if ($i -gt 1) { [timespan]::FromSeconds($sw.Elapsed.TotalSeconds / $i * ($n - $i)) } else { [timespan]::Zero }
        Write-Progress -Activity 'Извлечение текста титулов' -Status ("{0} из {1}, осталось ~{2:hh\:mm\:ss}" -f $i, $n, $left) -PercentComplete ($i * 100 / $n)
    }
    $shifr = ([regex]::Matches(($c.Имя + ' ' + [System.IO.Path]::GetFileName($c.Папка)), $ShifrRx) | ForEach-Object { $_.Value } | Select-Object -Unique) -join ' | '
    $body = ''; $st = ''; $note = ''
    $key = ($c.Имя + '|' + $c.Размер_КБ).ToLower()
    if ($prev.ContainsKey($c.Путь)) {
        $body, $st = $prev[$c.Путь][0], $prev[$c.Путь][1]
    } elseif ($seen.ContainsKey($key)) {
        $body, $st = $seen[$key][0], $seen[$key][1]; $note = 'копия: ' + $seen[$key][2]
    } else {
        try {
            switch ($c.Расширение) {
                '.docx' { $body, $st = Get-DocxText $c.Путь }
                '.doc'  { $body, $st = Get-DocText $c.Путь }
                '.pdf'  { $body, $st = Get-PdfText $c.Путь ([double]($c.Размер_КБ -replace ',', '.' -replace '\s', '')) }
                '.dwg'  { $note = 'dwg: текст не извлекается, только имя и путь' }
            }
        } catch {
            $nErr++; $note = 'ошибка чтения: ' + $_.Exception.Message
        }
        $body = Clean $body $BodyMax; $st = Clean $st $StampMax
        if ($c.Расширение -eq '.pdf' -and $pdftotext -and -not $body -and -not $note) { $note = 'нет текста (скан?)'; $nEmpty++ }
        $seen[$key] = @($body, $st, $c.Путь)
    }
    if ($body) { $nText++ }
    $row = @($i, $shifr, $c.Имя, $c.Расширение, $c.Размер_КБ, $c.Изменён, $c.Папка, $c.Путь, $body, $st, $note)
    $w.WriteLine((($row | ForEach-Object { Q $_ }) -join ';'))
    if (($i % 200) -eq 0) { $w.Flush() }
}
$w.Close()
Write-Progress -Activity 'Извлечение текста титулов' -Completed

# zip для загрузки в чат
$zipPath = [System.IO.Path]::ChangeExtension($csvPath, '.zip')
Compress-Archive -LiteralPath $csvPath -DestinationPath $zipPath -Force

Write-Host ''
Write-Host ("Готово за {0:hh\:mm\:ss}. Файлов: {1}, с текстом: {2}, PDF-сканов без текста: {3}, ошибок чтения: {4}" -f $sw.Elapsed, $n, $nText, $nEmpty, $nErr) -ForegroundColor Green
if (-not $pdftotext) { Write-Host 'PDF прочитаны не были: нет pdftotext.exe рядом со скриптом.' -ForegroundColor Yellow }
Write-Host "Таблица: $csvPath"
Write-Host ("Для загрузки в чат: {0} ({1:N1} МБ)" -f $zipPath, ((Get-Item -LiteralPath $zipPath).Length / 1MB)) -ForegroundColor Cyan
pause
